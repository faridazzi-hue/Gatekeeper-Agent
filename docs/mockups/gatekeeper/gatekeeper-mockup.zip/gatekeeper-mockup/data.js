// Illustrative offline fixture. All notifications, evidence and rules are simulated.
// Every evaluation mode reads these same results; opening details never rescores.
window.GATEKEEPER_DATA = {
  policy: {
    id: "DEMO-PM-01",
    version: "0.3",
    label: "Illustrative notification quality policy"
  },
  notifications: [
    {
      id: "10002256",
      title: "Cooling-water pump seal leak",
      type: "M2",
      equipmentId: "EQ-P104",
      equipmentName: "Cooling-water pump P-104",
      priority: "2 · High",
      abc: "Missing",
      planner: "MECH-01",
      fastEligible: false,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "pass", required: true, evidence: "M2 · PUMP catalog · LEAK damage code are populated in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "unknown", required: true, evidence: "The simulated equipment snapshot has no ABC classification. Asset criticality cannot be established.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "pass", required: true, evidence: "Planner group MECH-01 is assigned and valid in the demo lookup.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-P104 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "pass", required: true, evidence: "The complete simulated open-notification pool contains no matching issue for EQ-P104.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "pass", required: true, evidence: "Active leakage and reduced cooling flow support the recorded high priority in the demo rubric.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description identifies the seal location, active leak and reduced cooling flow.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Review needed",
      confidence: "Unrated",
      reason: "Required ABC evidence is missing. The other six checks pass, but approval cannot be rated until criticality is known.",
      route: "specialist"
    },
    {
      id: "10002195",
      title: "Compressor drive-end bearing vibration",
      type: "M2",
      equipmentId: "EQ-C201",
      equipmentName: "Air compressor C-201",
      priority: "2 · High",
      abc: "A",
      planner: "MECH-01",
      fastEligible: true,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "pass", required: true, evidence: "M2 · COMPRESSOR catalog · VIBRATION damage code are populated in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "pass", required: true, evidence: "The simulated equipment snapshot records classification A.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "pass", required: true, evidence: "Planner group MECH-01 is assigned and valid in the demo lookup.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-C201 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "pass", required: true, evidence: "The complete simulated open-notification pool contains no matching bearing-vibration issue for EQ-C201.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "pass", required: true, evidence: "Rising vibration, bearing temperature and continued duty support high priority in the demo rubric.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description specifies drive-end bearing, measured vibration and the operating condition.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Approve",
      confidence: "High",
      reason: "All seven required checks pass with complete evidence and no unresolved duplicate candidate.",
      route: "policy"
    },
    {
      id: "10002196",
      title: "Conveyor return roller seized",
      type: "M2",
      equipmentId: "EQ-CV018",
      equipmentName: "Packing conveyor CV-018",
      priority: "3 · Normal",
      abc: "B",
      planner: "MECH-02",
      fastEligible: true,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "pass", required: true, evidence: "M2 · CONVEYOR catalog · SEIZED damage code are populated in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "pass", required: true, evidence: "The simulated equipment snapshot records classification B.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "pass", required: true, evidence: "Planner group MECH-02 is assigned and valid in the demo lookup.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-CV018 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "pass", required: true, evidence: "The complete simulated open-notification pool contains no matching roller issue for EQ-CV018.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "pass", required: true, evidence: "A spare conveyor is available and no immediate production loss is reported; normal priority fits the demo rubric.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description identifies return roller 6, its seized state and visible belt wear.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Approve",
      confidence: "High",
      reason: "All seven required checks pass. The issue is actionable, correctly assigned and supported by complete evidence.",
      route: "policy"
    },
    {
      id: "10002215",
      title: "Feed pump suction pressure low",
      type: "M2",
      equipmentId: "EQ-P312",
      equipmentName: "Feed pump P-312",
      priority: "2 · High",
      abc: "A",
      planner: "MECH-01",
      fastEligible: true,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "fail", required: true, evidence: "M2 and the PUMP catalog are populated, but the required damage code is confirmed blank in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "pass", required: true, evidence: "The simulated equipment snapshot records classification A.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "pass", required: true, evidence: "Planner group MECH-01 is assigned and valid in the demo lookup.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-P312 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "pass", required: true, evidence: "The complete simulated open-notification pool contains no matching suction-pressure issue for EQ-P312.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "pass", required: true, evidence: "Sustained low suction pressure and feed instability support high priority in the demo rubric.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description states the suction-pressure reading, normal range and observed feed instability.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Rework",
      confidence: "High",
      reason: "The required damage code is confirmed blank. Complete the mandatory coding before resubmission.",
      route: "policy"
    },
    {
      id: "10002216",
      title: "Motor terminal-box gasket damaged",
      type: "M1",
      equipmentId: "EQ-M044",
      equipmentName: "Ventilation motor M-044",
      priority: "3 · Normal",
      abc: "C",
      planner: "Missing",
      fastEligible: true,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "pass", required: true, evidence: "M1 · MOTOR catalog · GASKET damage code are populated in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "pass", required: true, evidence: "The simulated equipment snapshot records classification C.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "fail", required: true, evidence: "The planner group is confirmed blank in the simulated notification; no responsible group is assigned.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-M044 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "pass", required: true, evidence: "The complete simulated open-notification pool contains no matching terminal-box issue for EQ-M044.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "pass", required: true, evidence: "The motor is isolated and a standby unit is available; normal priority fits the demo rubric.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description locates the damaged terminal-box gasket and documents visible moisture ingress.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Rework",
      confidence: "High",
      reason: "The responsible planner group is confirmed missing. Assign a valid group before resubmission.",
      route: "policy"
    },
    {
      id: "10002217",
      title: "Transfer pump seal leak after restart",
      type: "M2",
      equipmentId: "EQ-P203",
      equipmentName: "Transfer pump P-203",
      priority: "2 · High",
      abc: "B",
      planner: "MECH-02",
      fastEligible: false,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "pass", required: true, evidence: "M2 · PUMP catalog · LEAK damage code are populated in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "pass", required: true, evidence: "The simulated equipment snapshot records classification B.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "pass", required: true, evidence: "Planner group MECH-02 is assigned and valid in the demo lookup.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-P203 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "warning", required: true, evidence: "The complete demo pool includes simulated candidate DEMO-4108 on EQ-P203 with similar seal-leak wording. Timing suggests either a recurrence or the same unresolved issue.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "pass", required: true, evidence: "Active leakage after restart supports high priority in the demo rubric.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description identifies the seal location, restart timing and observed leak rate.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Review needed",
      confidence: "Medium",
      reason: "A similar open issue on the same equipment could be a duplicate or a recurrence. A specialist must resolve the relationship.",
      route: "specialist"
    },
    {
      id: "10002219",
      title: "Control valve fails to reach open position",
      type: "M2",
      equipmentId: "EQ-V118",
      equipmentName: "Control valve V-118",
      priority: "2 · High",
      abc: "A",
      planner: "INST-01",
      fastEligible: false,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "pass", required: true, evidence: "M2 · VALVE catalog · STROKE damage code are populated in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "pass", required: true, evidence: "The simulated equipment snapshot records classification A.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "pass", required: true, evidence: "Planner group INST-01 is assigned and valid in the demo lookup.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-V118 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "unknown", required: true, evidence: "The simulated duplicate-pool export omits the instrumentation planner group. No match was found in the available subset, but coverage is incomplete.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "pass", required: true, evidence: "Limited valve travel and reduced process throughput support high priority in the demo rubric.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description records the commanded and observed valve position plus the throughput effect.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Review needed",
      confidence: "Unrated",
      reason: "Duplicate coverage is incomplete. A no-match result from a partial pool cannot support approval or a confidence rating.",
      route: "specialist"
    },
    {
      id: "10002220",
      title: "Oil cooler outlet temperature rising",
      type: "M2",
      equipmentId: "EQ-H062",
      equipmentName: "Oil cooler H-062",
      priority: "1 · Urgent",
      abc: "B",
      planner: "MECH-01",
      fastEligible: false,
      checks: [
        { id: "coding", label: "Mandatory notification coding", status: "pass", required: true, evidence: "M2 · COOLER catalog · TEMP damage code are populated in the simulated record.", rule: "R-01 · Notification type, catalog and damage code must be present." },
        { id: "abc", label: "Equipment ABC classification", status: "pass", required: true, evidence: "The simulated equipment snapshot records classification B.", rule: "R-02 · An A, B or C equipment classification is required before approval; unavailable evidence requires review." },
        { id: "planner", label: "Planner assignment", status: "pass", required: true, evidence: "Planner group MECH-01 is assigned and valid in the demo lookup.", rule: "R-03 · A valid responsible planner group must be assigned." },
        { id: "equipment", label: "Equipment reference", status: "pass", required: true, evidence: "EQ-H062 resolves to one active equipment record in the demo snapshot.", rule: "R-04 · The equipment reference must resolve to one active asset." },
        { id: "duplicates", label: "Duplicate assessment", status: "pass", required: true, evidence: "The complete simulated open-notification pool contains no matching temperature issue for EQ-H062.", rule: "R-05 · Assess a complete duplicate pool; unresolved matches or incomplete coverage require review." },
        { id: "priority", label: "Priority justification", status: "warning", required: true, evidence: "The description reports a rising temperature below the alarm limit while standby cooling is available. The demo rubric does not clearly support urgent priority.", rule: "R-06 · Priority must have a clear rationale in the supplied condition evidence." },
        { id: "description", label: "Actionable issue description", status: "pass", required: true, evidence: "Description gives outlet-temperature readings over time, the alarm limit and standby availability.", rule: "R-07 · Describe the symptom, affected location and observed effect." }
      ],
      recommendation: "Review needed",
      confidence: "Medium",
      reason: "The recorded urgent priority needs interpretation against the temperature trend and available standby cooling.",
      route: "specialist"
    }
  ]
};
