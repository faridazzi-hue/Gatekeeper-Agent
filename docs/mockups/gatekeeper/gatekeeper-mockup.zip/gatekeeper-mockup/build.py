"""Build a single offline HTML file from the editable sources."""
from pathlib import Path

root = Path(__file__).parent
html = (root / "index.html").read_text()
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>\n' + (root / "styles.css").read_text() + '\n</style>')
scripts = '\n'.join((root / name).read_text() for name in ['data.js', 'app.js'])
scripts = scripts.replace('</script', '<\\/script')
html = html.replace('<script src="data.js"></script><script src="app.js"></script>', '<script>\n' + scripts + '\n</script>')
(root / "Gatekeeper-options.html").write_text(html)
print('Built Gatekeeper-options.html:', len(html.encode()), 'bytes')
