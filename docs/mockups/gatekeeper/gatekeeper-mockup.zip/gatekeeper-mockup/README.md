# Gatekeeper assessment design lab

Open **Gatekeeper-options.html** in a desktop browser. It is a standalone offline mockup: no installation, network, API credentials, or SAP connection is required.

## Explore the three options

1. **Complete batch:** click **Evaluate all 8**. Rows finish progressively. Open a notification to see the same saved recommendation, confidence, evidence and assessment ID.
2. **Selected working set:** choose the second card, reset the demo, select a few checkboxes, and click **Evaluate selected**. Unselected notifications remain unassessed.
3. **Policy + exceptions:** choose the third card, reset, and click **Apply policy to 8**. Four clear cases receive complete assessments; four remain exceptions without provisional recommendations. Click **Review exceptions**, or open one and review it individually.

Completed assessments are reused when switching modes. **Reset demo** in the top right cancels an in-progress simulation and clears its results so you can compare a fresh workflow.

## Test consistency and justified changes

- Evaluate notification **10002195**, then open it. The table and drawer show the same **Approve / High** result and assessment ID.
- Click **Simulate change**. The mock planner assignment is removed in a new evidence snapshot. The previous assessment is marked stale, and approval is unavailable.
- Click **Re-evaluate changes**. Both views update to **Rework / High**, revision 2, with an explanation of the new evidence. Opening the drawer alone never changes a result.
- **Review approvals** and **Simulate approval** require an explicit confirmation. Only current, complete approval recommendations are eligible. No SAP write is performed.

The fixture uses eight simulated notifications and seven illustrative checks. These are design examples, not the user's live SAP records or a company-approved policy. Confidence is qualitative; missing required evidence is explicitly **Unrated**. Animation durations illustrate workflow and are not performance benchmarks. State lives only in the current browser tab.

## Other interactions

- Search by ID, equipment or symptom; press `/` to focus search.
- Filter by assessment state or recommendation.
- Open **Compare approaches**, **Policy reference**, **Decision history**, or **Explore consistency**.
- Export simulated assessment records with the download icon.
- Press Escape to close a detail panel/dialog. Layout adapts to mobile.

## Editable files

- `index.html`: application layout.
- `styles.css`: responsive styling.
- `data.js`: illustrative notifications and canonical assessment findings.
- `app.js`: simulated scheduling, shared results, detail panels, revisions and approval flows.
- `build.py`: rebuilds the standalone HTML. Run `python3 build.py` after source changes.
- `browser-tests.cjs`: local Playwright interaction checks; requires Node, Playwright and Chromium.

Browser checks are run against the standalone HTML with external requests blocked. Preview screenshots and `test-results.json` are included when generated.
