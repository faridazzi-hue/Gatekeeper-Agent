(() => {
  'use strict';
  const data = window.GATEKEEPER_DATA;
  const notifications = data.notifications;
  const byId = Object.fromEntries(notifications.map(n => [n.id, n]));
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const paths = {
    grid:'<rect x="3" y="3" width="7" height="7" rx="1.4"/><rect x="14" y="3" width="7" height="7" rx="1.4"/><rect x="3" y="14" width="7" height="7" rx="1.4"/><rect x="14" y="14" width="7" height="7" rx="1.4"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    shield:'<path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6z"/>',
    'shield-check':'<path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6z"/><path d="m8 12 3 3 5-6"/>',
    layers:'<path d="m12 3 10 5-10 5L2 8zM3 12l9 5 9-5M3 17l9 5 9-5"/>',
    'check-square':'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m7 12 3 3 7-7"/>',
    split:'<path d="M5 4v3c0 5 14 5 14 10v3M5 20v-3c0-5 14-5 14-10V4M16 7l3-3 3 3M16 17l3 3 3-3"/>',
    compare:'<path d="M8 3v18M16 3v18M4 7l4-4 4 4M12 17l4 4 4-4"/>',
    reset:'<path d="M3 10a9 9 0 1 1 2 8M3 4v6h6"/>',
    play:'<path d="m9 5 11 7-11 7z"/>',
    search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
    filter:'<path d="M3 5h18M6 12h12M10 19h4"/>',
    download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/>',
    lock:'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
    'arrow-right':'<path d="M4 12h16m-6-6 6 6-6 6"/>',
    'chevron-right':'<path d="m9 5 7 7-7 7"/>',
    'check-circle':'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    close:'<path d="m6 6 12 12M6 18 18 6"/>',
    alert:'<path d="m12 3 10 18H2zM12 9v5m0 3v.2"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.2"/>',
    minus:'<path d="M6 12h12"/>',
    file:'<path d="M14 2H5v20h14V7zM14 2v6h5M8 12h8m-8 4h8"/>'
  };
  const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.info}</svg>`;
  $$('[data-icon]').forEach(el => { el.innerHTML = icon(el.dataset.icon); });

  const state = {
    mode:'batch', selected:new Set(), records:{}, overrides:{}, busy:false,
    progress:null, drawer:null, modal:null, activity:[], generation:0,
    search:'', filter:'all', runSerial:0
  };
  let lastFocus = null;
  let toastTimer;
  const time = () => new Intl.DateTimeFormat('en-GB', {hour:'2-digit', minute:'2-digit', timeZone:'Africa/Casablanca'}).format(new Date());
  const policyLabel = `${data.policy.id} · v${data.policy.version}`;
  const fresh = r => !!r.assessment && r.assessment.sourceVersion === r.sourceVersion;
  const eligible = r => r.status === 'complete' && fresh(r) && r.assessment.recommendation === 'Approve' && !r.approval;
  const attention = r => r.status === 'exception' || (!!r.assessment && !fresh(r)) || (fresh(r) && r.assessment.recommendation === 'Review needed');
  const pending = r => ['unassessed','exception'].includes(r.status) || (!!r.assessment && !fresh(r));
  const statusNames = {pass:'Pass',fail:'Fail',unknown:'Not evaluated',warning:'Needs interpretation',na:'Not applicable'};
  const modeNames = {batch:'Complete batch',selected:'Selected working set',policy:'Policy + exceptions'};
  const guides = {
    batch:['The full review, applied to every notification.','Completed rows become available immediately. Opening details reuses their assessment; it never starts a competing review.','Complete evidence'],
    selected:['Choose the notifications you will work on today.','Select rows, then prepare their complete reviews. Everything outside your selection remains explicitly unassessed.','You control the scope'],
    policy:['Resolve clear cases. Give exceptions focused attention.','Policy checks complete four clear cases in this example. Four exceptions wait for an individual or grouped review.','Evidence before decisions']
  };

  function initialiseRecords() {
    state.records = Object.fromEntries(notifications.map(n => [n.id, {status:'unassessed',sourceVersion:1,assessment:null,approval:null}]));
  }
  function scenario(id) {
    const n = JSON.parse(JSON.stringify(byId[id]));
    if (state.overrides[id]) {
      n.planner = 'Missing'; n.fastEligible = true; n.route = 'policy';
      const check = n.checks.find(c => c.id === 'planner');
      check.status = 'fail';
      check.evidence = 'In simulated evidence version 2, the planner assignment was removed. This is a new, verified missing mandatory field.';
      n.recommendation = 'Rework'; n.confidence = 'High';
      n.reason = 'New evidence confirms that the mandatory planner assignment was removed. Rework is required; the prior approval recommendation is superseded.';
    }
    return n;
  }
  function log(title, description='') {
    state.activity.unshift({time:time(),title,description});
  }
  function toast(message) {
    clearTimeout(toastTimer);
    const el = $('#toast'); el.textContent = message; el.hidden = false;
    toastTimer = setTimeout(() => { el.hidden = true; },4200);
  }
  function announce(message) { $('#announcer').textContent = message; }
  function reset() {
    state.generation++; state.selected.clear(); state.overrides = {}; state.busy = false;
    state.progress = null; state.drawer = null; state.modal = null; state.activity = [];
    state.search = ''; state.filter = 'all'; state.runSerial = 0;
    initialiseRecords(); $('#search').value = ''; $('#filter').value = 'all';
    $('#modal-overlay').hidden = true; document.body.style.overflow = '';
    render(); announce('Demo reset. All eight notifications are unassessed.');
  }
  function switchMode(mode) {
    if (!guides[mode]) return;
    state.mode = mode;
    $$('.mode-card').forEach(el => {
      const active = el.dataset.mode === mode;
      el.classList.toggle('selected',active); el.setAttribute('aria-pressed',String(active));
    });
    render();
    announce(`${modeNames[mode]} selected. Existing assessments are reused.`);
  }
  function visibleNotifications() {
    const query = state.search.toLowerCase().trim();
    return notifications.filter(n => {
      const r = state.records[n.id];
      if (query && !`${n.id} ${n.title} ${n.equipmentId} ${n.equipmentName}`.toLowerCase().includes(query)) return false;
      switch (state.filter) {
        case 'unassessed': return !r.assessment;
        case 'approve': return fresh(r) && r.assessment.recommendation === 'Approve';
        case 'rework': return fresh(r) && r.assessment.recommendation === 'Rework';
        case 'review': return attention(r);
        case 'stale': return !!r.assessment && !fresh(r);
        default: return true;
      }
    });
  }
  function recommendationBadge(result, stale=false) {
    if (!result) return '<span class="small-dash">—</span>';
    const name = result.recommendation;
    const style = name === 'Approve' ? 'success' : name === 'Rework' ? 'warning' : 'blue';
    return `<span class="badge ${stale ? 'neutral' : style}" ${stale ? 'title="Previous assessment. New evidence requires re-evaluation."' : ''}>${name === 'Approve' ? icon('check') : name === 'Rework' ? icon('alert') : icon('info')}${esc(name)}</span>`;
  }
  function confidenceMarkup(result) {
    if (!result) return '<span class="small-dash">—</span>';
    const confidence = result.confidence;
    const title = confidence === 'High' ? 'Conclusive evidence supports this recommendation; not a probability.' : confidence === 'Medium' ? 'Some interpretation requires reviewer attention; not a probability.' : 'Required evidence is unavailable. No substantive approval confidence is assigned.';
    return `<span class="confidence ${confidence.toLowerCase()}" title="${title}"><span class="confidence-dot"></span>${esc(confidence)}</span>`;
  }
  function assessmentBadge(r) {
    if (r.assessment && !fresh(r)) return `<span class="badge warning">${icon('alert')}Evidence changed</span>`;
    if (r.status === 'running') return '<span class="badge blue"><span class="spinner"></span>Evaluating</span>';
    if (r.status === 'queued') return `<span class="badge neutral">${icon('clock')}Queued</span>`;
    if (r.status === 'exception') return `<span class="badge warning">${icon('split')}Needs analysis</span>`;
    if (r.status === 'complete') return `<span class="badge success">${icon('check-circle')}Assessed</span>`;
    return '<span class="badge neutral">Not assessed</span>';
  }
  function renderStats() {
    const records = Object.values(state.records);
    const completed = records.filter(r => r.status === 'complete' && fresh(r)).length;
    $('#stat-total').textContent = notifications.length;
    $('#stat-complete').innerHTML = `${completed}<span>/${notifications.length}</span>`;
    $('#stat-complete-sub').textContent = state.busy ? 'assessments in progress' : 'current assessments';
    $('#stat-rework').textContent = records.filter(r => fresh(r) && r.assessment.recommendation === 'Rework').length;
    $('#stat-attention').textContent = records.filter(attention).length;
  }
  function renderGuide() {
    const [title,copy,tag] = guides[state.mode];
    $('#mode-guide').innerHTML = `<span class="guide-icon">${icon(state.mode === 'policy' ? 'split' : 'info')}</span><div class="guide-copy"><strong>${title}</strong><p>${copy}</p></div><span class="guide-tag">${tag}</span>`;
    const p = state.progress;
    const region = $('#progress-region');
    region.hidden = !p;
    if (p) {
      region.innerHTML = `<div class="progress-copy"><strong>${state.busy ? '<span class="spinner"></span>' : icon('check-circle')}${esc(p.title)}</strong><span>${p.done} / ${p.total} processed</span></div><div class="progress-track" role="progressbar" aria-label="Assessment progress" aria-valuemin="0" aria-valuemax="${p.total}" aria-valuenow="${p.done}"><div class="progress-fill" style="width:${p.total ? p.done / p.total * 100 : 0}%"></div></div>`;
    }
  }
  function renderActions() {
    const remaining = notifications.filter(n => pending(state.records[n.id]));
    const selectedPending = [...state.selected].filter(id => pending(state.records[id]));
    const primary = $('#evaluate-button');
    let label,disabled;
    if (state.busy) { label = 'Assessment in progress'; disabled = true; }
    else if (state.mode === 'batch') { label = remaining.length ? `Evaluate ${remaining.length === notifications.length ? 'all ' : 'remaining '}${remaining.length}` : 'All notifications assessed'; disabled = !remaining.length; }
    else if (state.mode === 'selected') { label = state.selected.size ? `Evaluate selected (${selectedPending.length})` : 'Select notifications'; disabled = !selectedPending.length; }
    else {
      const unassessed = remaining.filter(n => state.records[n.id].status !== 'exception');
      const exceptions = remaining.filter(n => state.records[n.id].status === 'exception');
      label = unassessed.length ? `Apply policy to ${unassessed.length}` : exceptions.length ? `Review exceptions (${exceptions.length})` : 'All notifications assessed';
      disabled = !remaining.length;
    }
    primary.disabled = disabled;
    primary.innerHTML = `${state.busy ? '<span class="spinner"></span>' : icon(state.mode === 'policy' ? 'split' : 'play')}<span>${label}</span>`;
    const approvals = Object.values(state.records).filter(eligible).length;
    $('#approve-button').disabled = !approvals || state.busy;
    $('#approve-button').innerHTML = `${icon('check-circle')}<span>Review approvals${approvals ? ` (${approvals})` : ''}</span>`;
    $('#selected-count').textContent = `${state.selected.size} selected`;
    $('#selected-count').classList.toggle('has-selection',!!state.selected.size);
    $('#worklist-caption').textContent = state.mode === 'selected' ? 'Select a working set. Unselected rows receive no recommendation.' : state.mode === 'policy' ? 'Evidence-complete cases finish first. Exceptions remain visible until reviewed.' : 'No provisional approvals. Recommendations appear only after assessment.';
  }
  function renderTable() {
    const visible = visibleNotifications();
    $('#table-count').textContent = visible.length;
    $('#visible-count').textContent = `Showing ${visible.length} of ${notifications.length} notifications`;
    $('#select-all').checked = !!visible.length && visible.every(n => state.selected.has(n.id));
    $('#select-all').indeterminate = visible.some(n => state.selected.has(n.id)) && !$('#select-all').checked;
    $('#table-body').innerHTML = visible.length ? visible.map(n => {
      const r = state.records[n.id], result = r.assessment;
      const stale = result && !fresh(r);
      const priorityStyle = n.priority.toLowerCase().includes('very high') ? 'very-high' : n.priority.toLowerCase().includes('high') ? 'high' : '';
      return `<tr data-id="${n.id}" class="${state.selected.has(n.id) ? 'selected-row' : ''}"><td class="checkbox-cell"><input type="checkbox" class="row-select" value="${n.id}" aria-label="Select notification ${n.id}" ${state.selected.has(n.id) ? 'checked' : ''}></td><td><button class="notif-link" data-action="open" data-id="${n.id}">${n.id}</button><span class="cell-title" title="${esc(n.title)}">${esc(n.title)}</span></td><td><span class="equipment-id">${esc(n.equipmentId)}</span><span class="equipment-name" title="${esc(n.equipmentName)}">${esc(n.equipmentName)}</span></td><td><span class="priority ${priorityStyle}"><i></i>${esc(n.priority.replace(/^\d+\s*·\s*/,''))}</span></td><td>${assessmentBadge(r)}</td><td class="result-cell">${recommendationBadge(result,stale)}</td><td class="confidence-cell">${confidenceMarkup(result)}</td><td class="decision-column"><span class="decision ${r.approval && fresh(r) ? 'approved' : ''}">${r.approval && fresh(r) ? '✓ Simulated approval' : result && fresh(r) ? 'Awaiting human' : '—'}</span></td><td><button class="row-arrow" data-action="open" data-id="${n.id}" aria-label="Open details for ${n.id}">${icon('chevron-right')}</button></td></tr>`;
    }).join('') : '<tr><td colspan="9" class="empty-state">No notifications match these filters. Try another search or view.</td></tr>';
  }
  function detailOverview(n) {
    return `<dl class="detail-overview"><div><dt>EQUIPMENT</dt><dd>${esc(n.equipmentId)} · ${esc(n.equipmentName)}</dd></div><div><dt>PLANT / TYPE</dt><dd>1710 / ${esc(n.type)}</dd></div><div><dt>PRIORITY / ABC</dt><dd>${esc(n.priority)} / ${esc(n.abc)}</dd></div><div><dt>PLANNER GROUP</dt><dd>${esc(n.planner)}</dd></div></dl>`;
  }
  function renderDrawer() {
    const panel = $('#drawer'), overlay = $('#drawer-overlay');
    panel.hidden = overlay.hidden = !state.drawer;
    if (!state.drawer) return;
    const id = state.drawer, n = scenario(id), r = state.records[id], result = r.assessment;
    const hasResult = !!result, stale = hasResult && !fresh(r);
    const heading = `<header class="drawer-head"><div class="drawer-eyebrow"><span>NOTIFICATION DETAIL</span><button class="icon-button" data-action="close-drawer" aria-label="Close notification details">${icon('close')}</button></div><h2 id="drawer-title">${id}</h2><p class="drawer-subtitle">${esc(n.title)}</p></header>`;
    if (!hasResult) {
      const processing = ['running','queued'].includes(r.status);
      const exception = r.status === 'exception';
      panel.innerHTML = `${heading}<div class="drawer-body">${detailOverview(n)}<div class="pending-detail"><span>${processing ? '<span class="spinner"></span>' : icon(exception ? 'split' : 'file')}</span><h3>${processing ? 'Your assessment is in progress' : exception ? 'This case needs focused analysis' : 'This notification is not assessed yet'}</h3><p>${processing ? 'This view will display the same completed result as the worklist. No second assessment is started.' : exception ? 'The policy pass identified an exception. Complete its review before a recommendation or confidence is shown.' : 'Prepare the assessment to see findings, a recommendation and its evidence. Opening details does not generate another opinion.'}</p><button class="button primary" data-action="evaluate-one" data-id="${id}" ${state.busy ? 'disabled' : ''}>${icon('play')}${exception ? 'Review this exception' : 'Evaluate this notification'}</button></div><p class="version-line">Seven illustrative checks · ${esc(policyLabel)}</p></div><div class="drawer-actions"><p>Recommendations remain hidden until this assessment is complete.</p><button class="button secondary" data-action="close-drawer">Back to worklist</button></div>`;
      return;
    }
    const resultClass = result.recommendation === 'Approve' ? '' : result.recommendation === 'Rework' ? 'rework' : 'review';
    const title = result.recommendation === 'Approve' ? 'Recommended for approval' : result.recommendation === 'Rework' ? 'Corrections required' : 'Human review needed';
    const previous = result.changedFrom;
    const changeNote = previous ? `<div class="change-note"><strong>Assessment revised after evidence changed</strong>${esc(previous.recommendation)} / ${esc(previous.confidence)} → ${esc(result.recommendation)} / ${esc(result.confidence)}. Planner assignment changed from present to missing. This revision is also shown in the worklist.</div>` : '';
    const staleNote = stale ? `<div class="stale-alert"><strong>Evidence changed. This assessment is out of date.</strong>Planner assignment was removed in evidence version ${r.sourceVersion}. The previous result below cannot be approved. Re-evaluate to create an explicit revision.</div>` : '';
    const checkContent = result.checks.map(c => `<div class="check ${c.status}"><span class="check-icon">${icon(c.status === 'pass' ? 'check' : c.status === 'fail' ? 'close' : c.status === 'na' ? 'minus' : c.status === 'unknown' ? 'info' : 'alert')}</span><div class="check-copy"><div class="check-top"><span class="check-title">${esc(c.label)}</span><span class="check-status">${statusNames[c.status]}</span></div><p>${esc(c.evidence)}</p><div class="check-rule">${esc(c.rule)}${c.required ? ' · Required' : ''}</div></div></div>`).join('');
    const same = `<div class="snapshot-note">${icon('lock')}Same assessment as the worklist · No recalculation on opening</div>`;
    const resultCard = `<section class="detail-result ${resultClass}" data-assessment-id="${esc(result.id)}"><span class="result-label">${stale ? 'PREVIOUS ASSESSMENT' : 'COMPLETED ASSESSMENT'}</span><h3>${title}</h3><p>${esc(result.reason)}</p><div class="confidence-line"><span>Recommendation confidence</span>${confidenceMarkup(result)}</div></section>`;
    const checksPassed = result.checks.filter(c => c.status === 'pass' || c.status === 'na').length;
    const meta = `<div class="assessment-meta"><div>ASSESSMENT ID<strong>${esc(result.id)}</strong></div><div>POLICY VERSION<strong>${esc(policyLabel)}</strong></div><div>EVIDENCE VERSION<strong>S${String(result.sourceVersion).padStart(3,'0')}${stale ? ' · superseded' : ' · current'}</strong></div><div>COMPLETED VIA<strong>${esc(result.via)}</strong></div></div>`;
    const demoChange = result.recommendation === 'Approve' && !stale ? `<div class="simulation-box"><div><strong>TRY AN EVIDENCE CHANGE</strong><p>Remove a planner assignment in a new mock snapshot.</p></div><button class="button secondary" data-action="change-evidence" data-id="${id}" ${state.busy ? 'disabled' : ''}>Simulate change</button></div>` : '';
    let footer;
    if (stale) footer = `<p>Re-evaluation is required before approval.</p><button class="button primary" data-action="evaluate-one" data-id="${id}" ${state.busy ? 'disabled' : ''}>${state.busy ? '<span class="spinner"></span>' : icon('reset')}Re-evaluate changes</button>`;
    else if (r.approval) footer = `<span class="detail-approved">${icon('check-circle')}Human approval simulated for ${esc(result.id)}</span><button class="button secondary" data-action="close-drawer">Done</button>`;
    else if (eligible(r)) footer = `<p>Final action requires your explicit confirmation. No SAP write is made.</p><button class="button approve" data-action="approve-one" data-id="${id}" ${state.busy ? 'disabled' : ''}>${icon('check-circle')}Simulate approval</button>`;
    else footer = `<p>${result.confidence === 'Unrated' ? 'Required evidence remains unavailable. Approval is disabled.' : 'This recommendation requires correction or human interpretation.'}</p><button class="button secondary" data-action="close-drawer">Back to worklist</button>`;
    panel.innerHTML = `${heading}<div class="drawer-body">${same}${staleNote}${changeNote}${resultCard}${detailOverview(n)}<div class="detail-section-head"><h3>Policy findings</h3><span>${checksPassed} / ${result.checks.length} checks satisfied</span></div>${checkContent}${meta}${demoChange}</div><div class="drawer-actions">${footer}</div>`;
  }
  function render() { renderStats(); renderGuide(); renderActions(); renderTable(); renderDrawer(); }
  function openDrawer(id) {
    if (!byId[id]) return;
    lastFocus = document.activeElement; state.drawer = id;
    renderDrawer(); document.body.style.overflow = 'hidden';
    requestAnimationFrame(() => $('[data-action="close-drawer"]', $('#drawer'))?.focus());
  }
  function closeDrawer() {
    state.drawer = null; $('#drawer').hidden = $('#drawer-overlay').hidden = true;
    if (!state.modal) document.body.style.overflow = '';
    if (lastFocus?.isConnected) lastFocus.focus();
  }
  function delay(ms) { return new Promise(resolve => setTimeout(resolve,ms)); }
  function finishAssessment(id, via) {
    const r = state.records[id], n = scenario(id), previous = r.assessment;
    const revision = previous ? previous.revision + 1 : 1;
    r.assessment = {
      id:`GK-${id}-R${revision}`,notificationId:id,revision,sourceVersion:r.sourceVersion,
      policyId:data.policy.id,policyVersion:data.policy.version,
      recommendation:n.recommendation,confidence:n.confidence,reason:n.reason,
      checks:n.checks,via,completedAt:new Date().toISOString(),
      changedFrom:previous ? {recommendation:previous.recommendation,confidence:previous.confidence,assessmentId:previous.id} : null
    };
    r.status = 'complete'; r.approval = null;
    log(`Assessment ready · ${id}`,`${n.recommendation} / ${n.confidence} · ${r.assessment.id} · evidence S${r.sourceVersion}`);
  }
  async function evaluate(ids, via='Complete review') {
    if (state.busy) return;
    const scope = [...new Set(ids)].filter(id => byId[id] && pending(state.records[id]));
    if (!scope.length) { toast('Current assessments are already available. Open details to inspect them.'); return; }
    const generation = state.generation;
    state.busy = true; state.runSerial++;
    scope.forEach(id => { state.records[id].status = 'queued'; });
    state.progress = {title:`Preparing ${scope.length} complete assessment${scope.length === 1 ? '' : 's'}`,done:0,total:scope.length};
    log(`Review started · ${scope.length} notification${scope.length === 1 ? '' : 's'}`,`${via}. Scope captured at start; later selection changes do not alter it.`);
    announce(state.progress.title); render();
    let cursor = 0;
    async function worker() {
      while (cursor < scope.length) {
        const index = cursor++, id = scope[index];
        if (state.generation !== generation) return;
        state.records[id].status = 'running'; render();
        await delay(420 + (index % 3) * 170);
        if (state.generation !== generation) return;
        finishAssessment(id,via); state.progress.done++; render();
      }
    }
    await Promise.all([worker(),worker()]);
    if (state.generation !== generation) return;
    state.busy = false;
    state.progress.title = `${scope.length} assessment${scope.length === 1 ? '' : 's'} complete · results are shared with details`;
    render(); announce(state.progress.title); toast(`${scope.length} complete assessment${scope.length === 1 ? '' : 's'} ready. Open a notification to inspect its saved result.`);
  }
  async function applyPolicy() {
    if (state.busy) return;
    const scope = notifications.filter(n => pending(state.records[n.id]) && state.records[n.id].status !== 'exception').map(n => n.id);
    if (!scope.length) {
      return evaluate(notifications.filter(n => state.records[n.id].status === 'exception').map(n => n.id),'Focused exception review');
    }
    const generation = state.generation;
    state.busy = true; scope.forEach(id => { state.records[id].status = 'queued'; });
    state.progress = {title:'Applying illustrative policy · evidence-complete cases first',done:0,total:scope.length};
    log('Policy pass started',`${scope.length} notifications · ${policyLabel}`); render();
    let cursor = 0;
    async function worker() {
      while (cursor < scope.length) {
        const id = scope[cursor++];
        if (state.generation !== generation) return;
        state.records[id].status = 'running'; render();
        await delay(230);
        if (state.generation !== generation) return;
        if (scenario(id).fastEligible) finishAssessment(id,'Evidence-complete policy path');
        else { state.records[id].status = 'exception'; log(`Exception identified · ${id}`,'No recommendation assigned. Focused review is required.'); }
        state.progress.done++; render();
      }
    }
    await Promise.all([worker(),worker()]);
    if (state.generation !== generation) return;
    state.busy = false;
    const exceptions = notifications.filter(n => state.records[n.id].status === 'exception').length;
    state.progress.title = exceptions ? `Policy pass complete · ${exceptions} exceptions need focused analysis` : 'Policy pass complete · all assessments ready';
    render(); announce(state.progress.title); toast(exceptions ? `${exceptions} cases remain in the exception queue. Review them together or open one individually.` : 'All policy assessments are ready.');
  }
  function runCurrentMode() {
    if (state.mode === 'policy') return applyPolicy();
    if (state.mode === 'selected') return evaluate([...state.selected],'Selected working set');
    return evaluate(notifications.map(n => n.id),'Complete batch');
  }
  function simulateChange(id) {
    const r = state.records[id];
    if (state.busy || !r || !fresh(r) || r.assessment.recommendation !== 'Approve') return;
    state.overrides[id] = true; r.sourceVersion++; r.approval = null;
    log(`Evidence changed · ${id}`,`Planner assignment removed in S${r.sourceVersion}. Previous assessment ${r.assessment.id} is out of date; approval disabled.`);
    render(); announce('Evidence changed. The previous assessment is stale. Re-evaluation is required.');
    toast('New evidence snapshot created. The prior result is preserved but cannot be approved.');
  }
  function modalHeader(title, intro) {
    return `<div class="modal-head"><div><div class="eyebrow">ASSESSMENT DESIGN LAB</div><h2 id="modal-title">${title}</h2></div><button class="icon-button" data-action="close-modal" aria-label="Close dialog">${icon('close')}</button></div><p class="modal-intro">${intro}</p>`;
  }
  function showModal(kind, ids) {
    lastFocus = document.activeElement;
    state.modal = {kind};
    const el = $('#modal');
    if (kind === 'compare') {
      el.innerHTML = `${modalHeader('Three approaches. One trusted result.','Choose what fits your team’s workload. All three approaches use the same illustrative policy and saved assessment; none produces provisional approval recommendations.')}<div class="compare-scroll"><table class="compare-table"><thead><tr><th></th><th>01 · Complete batch</th><th>02 · Working set</th><th>03 · Policy + exceptions</th></tr></thead><tbody><tr><td>What gets evaluated?</td><td>The entire worklist, with completed rows available progressively.</td><td>Only the notifications explicitly selected by the planner.</td><td>Evidence-complete cases first; exceptions receive focused analysis.</td></tr><tr><td>Before completion</td><td>Queued / Evaluating. No recommendation yet.</td><td>Unselected rows stay Not assessed.</td><td>Exceptions stay Needs analysis until their review completes.</td></tr><tr><td>Best fit</td><td>You need a prepared decision for every notification.</td><td>You handle only part of a large queue each day.</td><td>Many company rules can be evaluated reliably from structured evidence.</td></tr><tr><td>Trade-off</td><td>More total assessment work.</td><td>No decision for the rest of the worklist.</td><td>More policy definition and engineering.</td></tr><tr><td>Individual details</td><td colspan="3">Read the same assessment ID, findings, recommendation and confidence shown in the worklist. A new evidence snapshot requires an explicit revision.</td></tr></tbody></table></div><div class="metric-highlight"><strong>Try a fair comparison:</strong> select an approach, reset the demo and run it. The animation illustrates workflow only; it does not benchmark SAP or model performance.</div><div class="modal-bottom"><p>Completed results are reused when switching approaches. Reset creates a fresh simulated worklist.</p><button class="button primary" data-action="close-modal">Explore the worklist ${icon('arrow-right')}</button></div>`;
    } else if (kind === 'policy') {
      const rules = notifications[0].checks;
      el.innerHTML = `${modalHeader('The policy behind this example',`${esc(policyLabel)} · Illustrative rules only. This prototype does not represent a company-approved rulebook or connect to SAP.`)}<div class="policy-list">${rules.map(c => `<div class="policy-item"><span class="icon-wrap">${icon('shield-check')}</span><div><strong>${esc(c.label)}</strong><p>${esc(c.rule)}</p></div></div>`).join('')}</div><div class="metric-highlight"><strong>Outcome rules:</strong> a verified mandatory failure can support Rework / High. Required unavailable evidence produces Review needed / Unrated. An unresolved semantic exception produces Review needed / Medium. Approval requires conclusive applicable checks. Confidence is qualitative, not a measured probability.</div><div class="modal-bottom"><p>The fast path can complete only cases whose policy obligations are satisfied or whose decisive failure is established.</p><button class="button primary" data-action="close-modal">Understood</button></div>`;
    } else if (kind === 'activity') {
      el.innerHTML = `${modalHeader('Decision history','Each event belongs to a notification, assessment revision and evidence snapshot. All actions here are simulated.')}<div>${state.activity.length ? state.activity.slice(0,35).map(a => `<div class="activity-item"><time>${a.time}</time><div><strong>${esc(a.title)}</strong><p>${esc(a.description)}</p></div></div>`).join('') : '<div class="pending-detail"><h3>No decisions yet</h3><p>Run an assessment to see the shared results and revision history.</p></div>'}</div><div class="modal-bottom"><p>Approval never changes the recommendation or confidence. It records a separate human decision.</p><button class="button primary" data-action="close-modal">Back to worklist</button></div>`;
    } else if (kind === 'consistency') {
      el.innerHTML = `${modalHeader('Consistent does not mean frozen','Opening a detail view never creates another model opinion. Changes are allowed only through a visible, versioned assessment revision.')}<div class="policy-list"><div class="policy-item"><span class="icon-wrap">${icon('layers')}</span><div><strong>1 · One assessment, two views</strong><p>The worklist and detail panel display the same recommendation, confidence and assessment ID.</p></div></div><div class="policy-item"><span class="icon-wrap">${icon('alert')}</span><div><strong>2 · Evidence changes visibly</strong><p>On an approval recommendation, use Simulate change to remove its planner assignment. The previous assessment becomes stale and approval is disabled.</p></div></div><div class="policy-item"><span class="icon-wrap">${icon('reset')}</span><div><strong>3 · Re-evaluate explicitly</strong><p>The new evidence creates revision 2. Both views show Rework / High, with a reason explaining the change. High confidence can support a correction.</p></div></div></div><div class="modal-bottom"><p>Start with notification 10002195. Evaluate it first if it is still unassessed.</p><button class="button primary" data-action="open-example">Open example ${icon('arrow-right')}</button></div>`;
    } else if (kind === 'approvals') {
      const scope = (ids || notifications.map(n => n.id)).filter(id => eligible(state.records[id]));
      if (!scope.length) { state.modal = null; toast('No current approval recommendations are available.'); return; }
      state.modal.drafts = scope.map(id => ({id,assessmentId:state.records[id].assessment.id,sourceVersion:state.records[id].sourceVersion}));
      el.innerHTML = `${modalHeader('Confirm a simulated human decision','Review the exact notification and assessment versions below. This action records a demo approval only; it never calls SAP.')}<div class="approval-list">${scope.map(id => `<div class="approval-item"><div><strong>${id} · ${esc(byId[id].title)}</strong><p>${esc(state.records[id].assessment.id)} · evidence S${state.records[id].sourceVersion} · ${esc(policyLabel)}</p></div>${recommendationBadge(state.records[id].assessment)}</div>`).join('')}</div><label class="approval-confirm"><input type="checkbox" id="confirm-approval"><span>I reviewed these current assessments and explicitly confirm the simulated approval of these ${scope.length} notification${scope.length === 1 ? '' : 's'}.</span></label><div class="modal-bottom"><p>Rework, unresolved, stale and unassessed notifications are ineligible. The decision is bound to the versions listed above.</p><button class="button approve" data-action="confirm-approval" id="confirm-approval-button" disabled>Confirm ${scope.length} simulated approval${scope.length === 1 ? '' : 's'}</button></div>`;
    }
    $('#modal-overlay').hidden = false; document.body.style.overflow = 'hidden';
    requestAnimationFrame(() => $('[data-action="close-modal"]',el)?.focus());
  }
  function closeModal() {
    state.modal = null; $('#modal-overlay').hidden = true;
    if (!state.drawer) document.body.style.overflow = '';
    if (lastFocus?.isConnected) lastFocus.focus();
  }
  function confirmApprovals() {
    if (state.modal?.kind !== 'approvals' || !$('#confirm-approval')?.checked) return;
    const drafts = state.modal.drafts;
    const valid = drafts.every(d => {
      const r = state.records[d.id];
      return eligible(r) && r.assessment.id === d.assessmentId && r.sourceVersion === d.sourceVersion;
    });
    if (!valid) { closeModal(); toast('An assessment changed. Review the current version before confirming.'); return; }
    drafts.forEach(d => {
      state.records[d.id].approval = {assessmentId:d.assessmentId,sourceVersion:d.sourceVersion,at:new Date().toISOString()};
      log(`Human approval simulated · ${d.id}`,`${d.assessmentId} · explicit confirmation recorded. No SAP write.`);
    });
    closeModal(); render(); announce(`${drafts.length} simulated approvals recorded.`);
    toast(`${drafts.length} human approval${drafts.length === 1 ? '' : 's'} simulated. No SAP changes were made.`);
  }
  function exportResults() {
    const payload = {prototype:true,policy:data.policy,exportedAt:new Date().toISOString(),assessments:Object.entries(state.records).filter(([,r]) => r.assessment).map(([id,r]) => ({notificationId:id,currentEvidenceVersion:r.sourceVersion,current:fresh(r),assessment:r.assessment,humanDecision:r.approval}))};
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'gatekeeper-demo-assessments.json'; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url),1000);
    toast(`Exported ${payload.assessments.length} simulated assessment${payload.assessments.length === 1 ? '' : 's'}.`);
  }
  document.addEventListener('click',event => {
    const mode = event.target.closest('[data-mode]');
    if (mode) { switchMode(mode.dataset.mode); return; }
    const el = event.target.closest('[data-action]');
    if (!el || el.disabled) return;
    event.preventDefault();
    const id = el.dataset.id;
    switch (el.dataset.action) {
      case 'home': closeModal(); closeDrawer(); $('#worklist-title').scrollIntoView({behavior:'smooth',block:'center'}); break;
      case 'reset': reset(); toast('Fresh worklist. Choose an approach and try it.'); break;
      case 'evaluate': runCurrentMode(); break;
      case 'evaluate-one': evaluate([id],state.records[id].status === 'exception' ? 'Focused exception review' : 'Individual review'); break;
      case 'open': openDrawer(id); break;
      case 'close-drawer': closeDrawer(); break;
      case 'compare': showModal('compare'); break;
      case 'policy': showModal('policy'); break;
      case 'activity': showModal('activity'); break;
      case 'consistency': showModal('consistency'); break;
      case 'close-modal': closeModal(); break;
      case 'open-example': closeModal(); openDrawer('10002195'); break;
      case 'approvals': showModal('approvals'); break;
      case 'approve-one': showModal('approvals',[id]); break;
      case 'confirm-approval': confirmApprovals(); break;
      case 'change-evidence': simulateChange(id); break;
      case 'export': exportResults(); break;
    }
  });
  document.addEventListener('change',event => {
    if (event.target.matches('.row-select')) {
      const id = event.target.value;
      event.target.checked ? state.selected.add(id) : state.selected.delete(id); renderActions(); renderTable();
    }
    if (event.target.id === 'select-all') {
      visibleNotifications().forEach(n => event.target.checked ? state.selected.add(n.id) : state.selected.delete(n.id)); renderActions(); renderTable();
    }
    if (event.target.id === 'filter') { state.filter = event.target.value; renderTable(); }
    if (event.target.id === 'confirm-approval') $('#confirm-approval-button').disabled = !event.target.checked;
  });
  $('#search').addEventListener('input',event => { state.search = event.target.value; renderTable(); });
  $('#drawer-overlay').addEventListener('click',closeDrawer);
  $('#modal-overlay').addEventListener('click',event => { if (event.target.id === 'modal-overlay') closeModal(); });
  document.addEventListener('keydown',event => {
    if (event.key === 'Escape') { if (state.modal) closeModal(); else if (state.drawer) closeDrawer(); }
    if (event.key === '/' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName) && !state.modal && !state.drawer) { event.preventDefault(); $('#search').focus(); }
    if (event.key === 'Tab' && (state.modal || state.drawer)) {
      const container = state.modal ? $('#modal') : $('#drawer');
      const focusable = $$('button:not(:disabled),input:not(:disabled),select:not(:disabled),a[href],[tabindex="0"]',container).filter(el => el.getClientRects().length);
      const first = focusable[0], last = focusable[focusable.length-1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  });
  window.GATEKEEPER_DEMO = Object.freeze({
    getState:() => JSON.parse(JSON.stringify({...state,selected:[...state.selected]}))
  });
  $('.page-footer>span:last-child').textContent = `Assessment design lab · ${policyLabel}`;
  initialiseRecords(); render();
})();
