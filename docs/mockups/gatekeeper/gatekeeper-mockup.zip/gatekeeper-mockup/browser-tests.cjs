const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const results = [];

(async () => {
  const browser = await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const context = await browser.newContext({viewport:{width:1600,height:1100},deviceScaleFactor:1,offline:true});
  const page = await context.newPage();
  const errors = [];
  const externalRequests = [];
  page.on('pageerror',error => errors.push(error.message));
  page.on('request',request => { if (!request.url().startsWith('file:') && !request.url().startsWith('data:')) externalRequests.push(request.url()); });
  const getState = () => page.evaluate(() => window.GATEKEEPER_DEMO.getState());
  const waitForIdle = () => page.waitForFunction(() => !window.GATEKEEPER_DEMO.getState().busy);
  const open = id => page.locator(`.notif-link[data-id="${id}"]`).click();
  const close = () => page.getByRole('button',{name:'Close notification details',exact:true}).click();
  const reset = () => page.locator('[data-action="reset"]').click();
  async function check(name,fn) {
    if (process.argv[2] && !name.toLowerCase().includes(process.argv[2].toLowerCase())) return;
    await fn(); results.push({name,status:'passed'}); console.log('PASS',name);
  }
  // The managed runner disallows file:// navigation. Render the exact standalone
  // document in memory; its scripts/styles are embedded and need no requests.
  await page.setContent(fs.readFileSync(path.join(root,'Gatekeeper-options.html'),'utf8'),{waitUntil:'load'});
  await page.waitForSelector('#table-body tr');

  await check('Initial rows show no premature recommendation; opening details does not assess',async () => {
    assert.equal(await page.locator('#table-body tr').count(),8);
    assert.equal(await page.locator('.result-cell .badge').count(),0);
    const before = JSON.stringify((await getState()).records);
    await open('10002256');
    assert.match(await page.locator('#drawer').innerText(),/not assessed yet/);
    assert.equal(JSON.stringify((await getState()).records),before);
    await close();
    await page.screenshot({path:path.join(root,'preview-initial.png'),fullPage:true});
  });

  let fullResults;
  await check('Complete batch evaluates eight, and detail always matches the saved table result',async () => {
    await page.locator('#evaluate-button').click();
    await waitForIdle();
    const state = await getState();
    assert.equal(Object.values(state.records).filter(r => r.status === 'complete').length,8);
    assert.equal(Object.values(state.records).filter(r => r.assessment.recommendation === 'Approve').length,2);
    fullResults = Object.fromEntries(Object.entries(state.records).map(([id,r]) => [id,{recommendation:r.assessment.recommendation,confidence:r.assessment.confidence,checks:r.assessment.checks}]));
    await page.locator('#toast').waitFor({state:'hidden'});
    await page.screenshot({path:path.join(root,'preview.png'),fullPage:true});
    const before = JSON.stringify(state.records);
    for (const [id,r] of Object.entries(state.records)) {
      const row = page.locator(`tr[data-id="${id}"]`);
      assert.equal((await row.locator('.result-cell').innerText()).trim(),r.assessment.recommendation);
      assert.equal((await row.locator('.confidence-cell').innerText()).trim(),r.assessment.confidence);
      await open(id);
      assert.equal(await page.locator('.detail-result').getAttribute('data-assessment-id'),r.assessment.id);
      assert.equal((await page.locator('.confidence-line .confidence').innerText()).trim(),r.assessment.confidence);
      assert.ok((await page.locator('#drawer').innerText()).includes(r.assessment.reason));
      await close();
    }
    assert.equal(JSON.stringify((await getState()).records),before);
    await open('10002195');
    await page.screenshot({path:path.join(root,'preview-detail.png'),animations:'disabled'});
    await close();
  });

  await check('Human approval is explicit and bound to a current completed assessment',async () => {
    await open('10002195');
    await page.locator('[data-action="approve-one"]').click();
    assert.equal(await page.locator('#confirm-approval-button').isDisabled(),true);
    await page.locator('#confirm-approval').check();
    await page.locator('#confirm-approval-button').click();
    const r = (await getState()).records['10002195'];
    assert.equal(r.approval.assessmentId,r.assessment.id);
    assert.equal(r.assessment.confidence,'High');
    await close();
    await open('10002256');
    assert.equal(await page.locator('[data-action="approve-one"]').count(),0);
    await close();
  });

  await check('Changed evidence disables approval; explicit re-evaluation updates both views with revision 2',async () => {
    await open('10002195');
    await page.locator('[data-action="change-evidence"]').click();
    let r = (await getState()).records['10002195'];
    assert.equal(r.sourceVersion,2);
    assert.equal(r.assessment.sourceVersion,1);
    assert.equal(r.approval,null);
    assert.equal(await page.locator('[data-action="approve-one"]').count(),0);
    assert.match(await page.locator('.stale-alert').innerText(),/out of date/);
    await page.screenshot({path:path.join(root,'preview-evidence-change.png'),animations:'disabled'});
    await page.locator('[data-action="evaluate-one"]').click();
    await waitForIdle();
    r = (await getState()).records['10002195'];
    assert.equal(r.assessment.recommendation,'Rework');
    assert.equal(r.assessment.confidence,'High');
    assert.equal(r.assessment.revision,2);
    assert.equal(r.assessment.sourceVersion,2);
    assert.match(await page.locator('.change-note').innerText(),/Approve \/ High → Rework \/ High/);
    await close();
    assert.equal((await page.locator('tr[data-id="10002195"] .result-cell').innerText()).trim(),'Rework');
  });

  await check('Reset cancels an in-progress simulation without stale timer results',async () => {
    await reset();
    await page.locator('#evaluate-button').click();
    await reset();
    await page.waitForTimeout(1000);
    const state = await getState();
    assert.equal(state.busy,false);
    assert.equal(Object.values(state.records).filter(r => r.assessment).length,0);
  });

  await check('Working-set scope is captured at start; unselected details cannot create a second assessment',async () => {
    await page.locator('[data-mode="selected"]').click();
    for (const id of ['10002256','10002195','10002215']) await page.locator(`.row-select[value="${id}"]`).check();
    await page.locator('#evaluate-button').click();
    await page.locator('.row-select[value="10002196"]').check();
    await waitForIdle();
    const state = await getState();
    assert.equal(Object.values(state.records).filter(r => r.assessment).length,3);
    assert.equal(state.records['10002196'].assessment,null);
    await page.screenshot({path:path.join(root,'preview-working-set.png'),fullPage:true});
    await open('10002196'); await close();
    assert.equal((await getState()).records['10002196'].assessment,null);
    const before = JSON.stringify((await getState()).records);
    await page.locator('[data-mode="batch"]').click();
    assert.equal(JSON.stringify((await getState()).records),before);
  });

  await check('Policy fast path leaves unresolved exceptions without recommendations; focused review shares final outcomes',async () => {
    await reset();
    await page.locator('[data-mode="policy"]').click();
    await page.locator('#evaluate-button').click(); await waitForIdle();
    let state = await getState();
    assert.equal(Object.values(state.records).filter(r => r.status === 'complete').length,4);
    assert.equal(Object.values(state.records).filter(r => r.status === 'exception').length,4);
    for (const [id,r] of Object.entries(state.records).filter(([,r]) => r.status === 'exception')) {
      assert.equal(r.assessment,null);
      assert.equal((await page.locator(`tr[data-id="${id}"] .result-cell`).innerText()).trim(),'—');
    }
    await page.screenshot({path:path.join(root,'preview-policy.png'),fullPage:true});
    await open('10002256');
    await page.locator('[data-action="evaluate-one"]').click(); await waitForIdle();
    assert.equal((await getState()).records['10002256'].assessment.confidence,'Unrated');
    await close();
    await page.locator('#evaluate-button').click(); await waitForIdle();
    state = await getState();
    assert.equal(Object.values(state.records).filter(r => r.assessment).length,8);
    for (const [id,r] of Object.entries(state.records)) assert.deepEqual({recommendation:r.assessment.recommendation,confidence:r.assessment.confidence,checks:r.assessment.checks},fullResults[id]);
  });

  await check('Search, filters, dialog keyboard controls, and JSON export work',async () => {
    await page.locator('#search').fill('10002256');
    assert.equal(await page.locator('#table-body tr').count(),1);
    await page.locator('#search').fill('');
    await page.locator('#filter').selectOption('approve');
    assert.equal(await page.locator('#table-body tr').count(),2);
    await page.locator('#filter').selectOption('all');
    await page.locator('[data-action="compare"]').click();
    assert.equal(await page.locator('#modal-overlay').isVisible(),true);
    await page.keyboard.press('Escape');
    assert.equal(await page.locator('#modal-overlay').isVisible(),false);
    const downloadPromise = page.waitForEvent('download');
    await page.locator('[data-action="export"]').click();
    const download = await downloadPromise;
    const temporary = path.join('/tmp','gatekeeper-demo-export.json');
    await download.saveAs(temporary);
    const exported = JSON.parse(fs.readFileSync(temporary,'utf8'));
    assert.equal(exported.prototype,true);
    assert.equal(exported.assessments.length,8);
    assert.equal(exported.assessments.find(a => a.notificationId === '10002256').assessment.confidence,'Unrated');
  });

  await check('Mobile layout keeps the page within the viewport and supports the detail panel',async () => {
    await page.setViewportSize({width:390,height:844});
    const layout = await page.evaluate(() => ({width:window.innerWidth,scrollWidth:document.documentElement.scrollWidth,overflow:Array.from(document.querySelectorAll('body *')).filter(el=>{const r=el.getBoundingClientRect();return r.width>0&&r.right>window.innerWidth+1&&getComputedStyle(el).position!=='fixed';}).slice(0,15).map(el=>({tag:el.tagName,class:el.className,right:Math.round(el.getBoundingClientRect().right)}))}));
    assert.equal(layout.scrollWidth,layout.width);
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    await page.screenshot({path:path.join(root,'preview-mobile.png'),fullPage:true});
    await open('10002256');
    assert.equal(await page.locator('#drawer').isVisible(),true);
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    await page.screenshot({path:path.join(root,'preview-mobile-detail.png'),animations:'disabled'});
    await close();
  });
  assert.deepEqual(errors,[]);
  assert.deepEqual(externalRequests,[]);
  fs.writeFileSync(path.join(root,'test-results.json'),JSON.stringify({status:'passed',checks:results,pageErrors:errors,externalRequests,scope:'Offline interactive mockup; no SAP or model requests.'},null,2));
  console.log(JSON.stringify({status:'passed',checks:results.length,pageErrors:errors.length,externalRequests:externalRequests.length}));
  await browser.close();
})().catch(error => {
  fs.writeFileSync(path.join(root,'test-results.json'),JSON.stringify({status:'failed',checks:results,error:String(error)},null,2));
  console.error(error);process.exit(1);
});
