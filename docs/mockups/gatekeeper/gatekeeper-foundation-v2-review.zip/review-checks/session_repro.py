"""Focused foundation-v2 session reproductions; source is never modified."""
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source"))
from assessment_models import AssessmentRecord, ActionContext, WorklistSnapshot
import assessment_session as session

A = ("alice", "tenant", "conversation-a")
B = ("bob", "tenant", "conversation-b")


def record(nid="1000", revision=1):
    return AssessmentRecord(notification_id=nid, recommendation="Rework", confidence="High",
                            rationale="fixture", revision=revision)


def rejected_publish_evicts_unrelated_scope():
    store = session.SessionAssessmentStore(max_scopes=1)
    old_generation = store.generation(A)
    current = record()
    store.publish(B, current)
    assert store.get_current(B, "1000") is not None
    accepted = store.publish(A, record(), expected_generation=old_generation)
    assert accepted is False
    return {"accepted_stale_record": accepted,
            "unrelated_live_record_survived": store.get_current(B, "1000") is not None,
            "obsolete_scope_recreated": A in store._scopes}


def rejected_publish_extends_session_lifetime():
    clock = [1000.0]
    with patch.object(session, "_now", side_effect=lambda: clock[0]):
        store = session.SessionAssessmentStore(ttl_seconds=10)
        old_generation = store.generation(A)
        store.invalidate_scope(A)
        store.publish(A, record(), expected_generation=store.generation(A))
        clock[0] += 9
        assert not store.publish(A, record(), expected_generation=old_generation)
        clock[0] += 2
        return {"record_readable_after_original_ttl": store.get_current(A, "1000") is not None,
                "last_touched": store._scopes[A].last_touched}


def snapshots_are_not_defensive_copies():
    store = session.SessionAssessmentStore()
    snap = WorklistSnapshot(actor="alice", plant="1710", ordered_ids=["1000"], total=1)
    store.put_snapshot(A, snap)
    returned = store.get_snapshot(A, snap.snapshot_id)
    returned.ordered_ids.append("NOT-IN-ORIGINAL-LIST")
    return {"stored_ids_after_mutating_getter": store.get_snapshot(A, snap.snapshot_id).ordered_ids}


def superseded_action_contexts_survive_record_eviction():
    store = session.SessionAssessmentStore(max_records_per_scope=2)
    for revision in range(1, 11):
        rec = record(revision=revision)
        store.publish(A, rec)
        store.issue_action(A, ActionContext(actor="alice", notification_id="1000",
                                           assessment_id=rec.assessment_id, revision=revision,
                                           action="rework"))
    b = store._scopes[A]
    return {"current_records": len(b.current), "assessment_index": len(b.by_assessment),
            "action_contexts": len(b.actions),
            "actions_whose_record_is_gone": sum(c.assessment_id not in b.by_assessment
                                               for c in b.actions.values())}


if __name__ == "__main__":
    import json
    for check in (rejected_publish_evicts_unrelated_scope, rejected_publish_extends_session_lifetime,
                  snapshots_are_not_defensive_copies, superseded_action_contexts_survive_record_eviction):
        print(json.dumps({"check": check.__name__, "observed": check()}))
