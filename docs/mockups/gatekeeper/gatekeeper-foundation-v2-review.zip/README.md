# Foundation v2 re-review handoff

Read FOUNDATION-V2-REVIEW.md. All five submitted hashes match, original12 and unchanged reviewer14 tests pass. Additional focused cases identify residual R1-R6. Integration deferrals are explicitly respected.

This package contains review documentation, input hashes, regression tests and captured outputs only. It contains no modified source or production implementation.

To run the follow-up tests, place the original six files from gatekeeper-assessment-foundation-v2.zip under source/ next to review-checks/, then run:

    python3 -B review-checks/models_repro.py
    python3 -B review-checks/service_repro.py
    python3 -B review-checks/test_session_followups.py

These expected-behavior tests currently fail on the submitted code. One service positive control passes. Six TypeErrors in schema subtests are actual submitted-parser errors, not missing dependencies. No SAP, model or network calls are made.

Keep the session-only design. No durable BTP data storage is required. Fix the focused remaining contracts before live wiring.
