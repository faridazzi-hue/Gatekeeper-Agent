"""Expected-behavior regressions for the submitted foundation (no SAP/model calls).

These should fail against the uploaded version and pass after the corresponding
fixes. They do not alter the submitted source. Set GATEKEEPER_FOUNDATION_SOURCE
to the directory containing the three modules when running outside this review.
"""
import asyncio
import json
import os
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

SOURCE = Path(os.environ.get(
    "GATEKEEPER_FOUNDATION_SOURCE", str(Path(__file__).resolve().parents[1] / "source")
))
sys.path.insert(0, str(SOURCE))

from assessment_models import ActionContext, AssessmentRecord, DuplicateEvidence, EvidenceFinding, PageRun, WorklistSnapshot
import assessment_session as session
from assessment_service import build_record, run_page

SCOPE = ("userA", "tenant1", "conv1")


def payload(nid="1000", **changes):
    value = {
        "notification_id": nid,
        "recommendation": "Approve", "confidence": "High", "rationale": "fixture",
        "execution_completeness": "complete", "incomplete_reason": "",
        "summary_fields": {"description": "Fixture", "priority": "High"},
        "duplicate": {"coverage": "complete", "candidate_ids": [], "pool_capped": False},
        "findings": [{"field": "Equipment", "retrieved_value": "EQ-1",
                      "result": "Pass", "evidence_available": True}],
    }
    value.update(changes)
    return value


def build(value):
    return build_record(value, notification_id="1000", revision=1, run_id=None, policy_version="p1")


def record(nid="1000"):
    return AssessmentRecord(notification_id=nid, recommendation="Rework", confidence="High",
                            rationale="Fixture", findings=[EvidenceFinding("Planner", "", "Fail")],
                            summary_fields={"description": "Original"})


class SchemaAndSessionRegressions(unittest.TestCase):
    def test_invalid_contract_is_incomplete(self):
        cases = [{}, {"recommendation": "Approve", "confidence": "High"},
                 payload(execution_completeness="required-source-failed")]
        for value in cases:
            with self.subTest(value=value):
                rec = build(value)
                self.assertEqual(rec.execution_completeness, "incomplete")
                self.assertIsNone(rec.recommendation)
                self.assertIsNone(rec.confidence)

    def test_unverified_duplicate_contract_cannot_approve(self):
        cases = [None, {"coverage": "complete", "candidate_ids": "1002"},
                 {"coverage": "complete", "candidate_ids": [], "pool_capped": True}]
        for duplicate in cases:
            with self.subTest(duplicate=duplicate):
                self.assertNotEqual(build(payload(duplicate=duplicate)).recommendation, "Approve")

    def test_response_identity_mismatch_is_incomplete(self):
        rec = build(payload(nid="9999"))
        self.assertEqual(rec.execution_completeness, "incomplete")
        self.assertIsNone(rec.recommendation)

    def test_boolean_string_is_schema_error(self):
        rec = build(payload(findings=[{"field": "Equipment", "result": "Pass",
                                      "evidence_available": "false"}]))
        self.assertEqual(rec.execution_completeness, "incomplete")
        self.assertIsNone(rec.recommendation)

    def test_published_snapshot_is_not_changed_by_caller(self):
        store = session.SessionAssessmentStore()
        original = record()
        store.publish(SCOPE, original)
        displayed = store.get_current(SCOPE, "1000")
        try:
            displayed.recommendation = "Approve"
            displayed.findings[0].result = "Pass"
            displayed.summary_fields["description"] = "Changed"
        except (AttributeError, TypeError):
            pass  # A deeply immutable snapshot is also an acceptable implementation.
        current = store.get_current(SCOPE, "1000")
        self.assertEqual(current.recommendation, "Rework")
        self.assertEqual(current.findings[0].result, "Fail")
        self.assertEqual(current.summary_fields["description"], "Original")

    def test_scope_eviction_rejects_older_worker(self):
        store = session.SessionAssessmentStore(max_scopes=1)
        generation = store.generation(SCOPE)
        store.generation(("userB", "tenant1", "conv2"))
        self.assertFalse(store.publish(SCOPE, record(), expected_generation=generation))

    def test_sweeping_expired_scope_rejects_older_worker(self):
        clock = [1000.0]
        with patch.object(session, "_now", side_effect=lambda: clock[0]):
            store = session.SessionAssessmentStore(ttl_seconds=10)
            generation = store.generation(SCOPE)
            clock[0] += 11
            store.sweep()
            self.assertFalse(store.publish(SCOPE, record(), expected_generation=generation))

    def test_invalidation_does_not_revive_expired_results(self):
        clock = [1000.0]
        with patch.object(session, "_now", side_effect=lambda: clock[0]):
            store = session.SessionAssessmentStore(ttl_seconds=10)
            store.publish(SCOPE, record())
            clock[0] += 11
            self.assertIsNone(store.get_current(SCOPE, "1000"))
            store.invalidate_scope(SCOPE)
            self.assertIsNone(store.get_current(SCOPE, "1000"))

    def test_used_nonce_cannot_be_reset_through_returned_object(self):
        store = session.SessionAssessmentStore()
        rec = record()
        store.publish(SCOPE, rec)
        ctx = ActionContext(actor="userA", notification_id="1000", assessment_id=rec.assessment_id,
                            revision=rec.revision, action="rework")
        store.issue_action(SCOPE, ctx)
        kwargs = dict(actor="userA", notification_id="1000", assessment_id=rec.assessment_id, action="rework")
        consumed = store.consume_action(SCOPE, ctx.nonce, **kwargs)
        self.assertIsNotNone(consumed)
        try:
            consumed.used = False
        except (AttributeError, TypeError):
            pass
        self.assertIsNone(store.consume_action(SCOPE, ctx.nonce, **kwargs))

    def test_record_cap_bounds_current_records(self):
        store = session.SessionAssessmentStore(max_records_per_scope=2)
        for nid in ("1000", "1001", "1002", "1003", "1004"):
            store.publish(SCOPE, record(nid))
        retained = sum(store.get_current(SCOPE, str(nid)) is not None for nid in range(1000, 1005))
        self.assertLessEqual(retained, 2)


class PageLifecycleRegressions(unittest.IsolatedAsyncioTestCase):
    def setup_run(self, ids, **kwargs):
        store = session.SessionAssessmentStore()
        snap = WorklistSnapshot(actor="userA", plant="1710", ordered_ids=ids, total=len(ids))
        store.put_snapshot(SCOPE, snap)
        run = PageRun(snapshot_id=snap.snapshot_id, page_index=1, member_ids=list(ids), actor="userA", **kwargs)
        return store, snap, run

    async def test_rejected_publication_is_not_completed(self):
        store, _, run = self.setup_run(["1000"])

        async def assessor(nid):
            store.invalidate_scope(SCOPE)
            return json.dumps(payload(nid))

        await run_page(run, assessor=assessor, scope=SCOPE, store=store)
        self.assertEqual(run.counts()["completed"], 0)

    async def test_queued_old_page_cannot_adopt_new_generation(self):
        store, _, run = self.setup_run(["1000", "1001"])

        async def assessor(nid):
            if nid == "1000":
                store.invalidate_scope(SCOPE)
            return json.dumps(payload(nid))

        await run_page(run, assessor=assessor, scope=SCOPE, store=store, sap_concurrency=1)
        self.assertIsNone(store.get_current(SCOPE, "1001"))

    async def test_duplicate_run_joins_existing_work(self):
        store, snap, first = self.setup_run(["1000"], idempotency_key="same-click")
        second = PageRun(snapshot_id=snap.snapshot_id, page_index=1, member_ids=["1000"],
                         actor="userA", idempotency_key="same-click")
        calls = 0

        async def assessor(nid):
            nonlocal calls
            calls += 1
            await asyncio.sleep(0)
            return json.dumps(payload(nid))

        await asyncio.gather(*(run_page(run, assessor=assessor, scope=SCOPE, store=store)
                               for run in (first, second)))
        self.assertEqual(calls, 1)

    async def test_cancelled_item_is_not_left_running(self):
        store, _, run = self.setup_run(["1000"])

        async def assessor(nid):
            raise asyncio.CancelledError()

        try:
            await run_page(run, assessor=assessor, scope=SCOPE, store=store)
        except asyncio.CancelledError:
            pass  # Propagation is fine if item state is settled before exit.
        self.assertEqual(run.counts()["running"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
