"""Reproduce foundation schema/snapshot defects without modifying submitted source.

Uses only standard library and submitted modules; makes no external requests.
Assertions document the observed unsafe behavior, rather than intended behavior.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

SOURCE = Path(__file__).resolve().parents[1] / "source"
sys.path.insert(0, str(SOURCE))

from assessment_models import AssessmentRecord, DuplicateEvidence, EvidenceFinding
from assessment_service import build_record
from assessment_session import SessionAssessmentStore


def build(obj: dict) -> AssessmentRecord:
    return build_record(obj, notification_id="1000", revision=1,
                        run_id="run_review", policy_version="policy_review")


def show(label: str, record: AssessmentRecord) -> None:
    print(json.dumps({
        "case": label,
        "notification_id": record.notification_id,
        "completeness": record.execution_completeness,
        "recommendation": record.recommendation,
        "confidence": record.confidence,
        "findings": len(record.findings),
        "duplicate_clean": record.duplicate.is_clean if record.duplicate else None,
    }))


def main() -> None:
    # No completeness, duplicate result, findings or rationale is required.
    rec = build({"recommendation": "Approve", "confidence": "High"})
    assert rec.recommendation == "Approve" and rec.execution_completeness == "complete"
    show("missing_required_contract_fields_approves", rec)

    # An invalid completeness token is silently interpreted as complete.
    rec = build({"recommendation": "Approve", "confidence": "High",
                 "execution_completeness": "required-source-failed"})
    assert rec.recommendation == "Approve" and rec.execution_completeness == "complete"
    show("invalid_completeness_approves", rec)

    # A malformed candidate list is discarded, making duplicate coverage clean.
    rec = build({"recommendation": "Approve", "confidence": "High",
                 "execution_completeness": "complete",
                 "duplicate": {"coverage": "complete", "candidate_ids": "1002"}})
    assert rec.recommendation == "Approve" and rec.duplicate.candidate_ids == []
    show("malformed_duplicate_candidates_erased", rec)

    rec = build({"recommendation": "Approve", "confidence": "High",
                 "execution_completeness": "complete",
                 "duplicate": {"coverage": "complete", "candidate_ids": [],
                               "pool_capped": True}})
    assert rec.recommendation == "Approve" and rec.duplicate.is_clean
    show("capped_duplicate_pool_still_clean", rec)

    # Even an explicitly unavailable finding does not make the item incomplete.
    rec = build({"recommendation": "Approve", "confidence": "High",
                 "execution_completeness": "complete",
                 "findings": [{"field": "Equipment", "retrieved_value": "",
                               "result": "Not verified", "evidence_available": False}]})
    assert rec.recommendation == "Approve" and not rec.findings[0].evidence_available
    show("unavailable_finding_but_approve", rec)

    rec = build({"recommendation": "Approve", "confidence": "High",
                 "execution_completeness": "complete",
                 "findings": [{"field": "Equipment", "retrieved_value": "",
                               "result": "Pass", "evidence_available": "false"}]})
    assert rec.findings[0].result == "Pass" and rec.findings[0].evidence_available is True
    show("string_false_is_true", rec)

    # Payload for another notification is accepted and relabelled as requested id.
    rec = build({"notification_id": "9999", "recommendation": "Approve",
                 "confidence": "High", "summary_fields": {"description": "For 9999"}})
    assert rec.notification_id == "1000" and rec.summary_fields["description"] == "For 9999"
    show("wrong_notification_payload_relabelled", rec)

    # Syntactically valid but schema-invalid JSON is marked completed.
    rec = build({})
    assert rec.execution_completeness == "complete" and rec.recommendation is None
    show("empty_object_marked_complete", rec)

    # A stored current record is returned by reference. Both its top-level verdict
    # and nested evidence can be mutated without changing assessment id/revision.
    store = SessionAssessmentStore()
    scope = ("actor", "tenant", "conversation")
    rec = AssessmentRecord(
        notification_id="1000", recommendation="Rework", confidence="Medium",
        rationale="Missing planner", findings=[EvidenceFinding("Planner", "", "Fail")],
        duplicate=DuplicateEvidence(coverage="partial", candidate_ids=["1002"]),
    )
    assert store.publish(scope, rec)
    original_id = rec.assessment_id
    details = store.get_current(scope, "1000")
    details.recommendation = "Approve"
    details.findings[0].result = "Pass"
    # This mutation even violates the constructor guard: Approve + partial pool.
    current = store.get_by_assessment_id(scope, original_id)
    assert current.recommendation == "Approve" and not current.duplicate.is_clean
    assert current.revision == 1 and current.findings[0].result == "Pass"
    show("same_revision_mutates_to_unsupported_approve", current)

    print("Reproduced 9 schema/snapshot issues; no submitted source files changed.")


if __name__ == "__main__":
    main()
