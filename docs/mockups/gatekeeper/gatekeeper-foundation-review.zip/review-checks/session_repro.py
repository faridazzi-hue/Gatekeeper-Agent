"""Isolated, deterministic repros for submitted foundation session-store behavior.

No source changes, network or SAP calls. Assertions establish each observed defect.
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source"))
import assessment_session as session
from assessment_models import AssessmentRecord, DuplicateEvidence, ActionContext

SCOPE = ("userA", "tenant1", "conversation1")
OTHER = ("userB", "tenant1", "conversation2")
CLOCK = [1000.0]
session._now = lambda: CLOCK[0]


def rec(nid="1000", **kwargs):
    return AssessmentRecord(notification_id=nid, recommendation="Approve", confidence="High",
                            rationale="original", duplicate=DuplicateEvidence(coverage="complete"),
                            **kwargs)


def context(record):
    return ActionContext(actor="userA", notification_id=record.notification_id,
                         assessment_id=record.assessment_id, revision=record.revision,
                         action="approval")


def sweep_resurrection():
    CLOCK[0] = 1000.0
    store = session.SessionAssessmentStore(ttl_seconds=10)
    generation = store.generation(SCOPE)
    CLOCK[0] += 11
    removed = store.sweep()
    record = rec()
    accepted = store.publish(SCOPE, record, expected_generation=generation)
    assert removed == 1 and accepted
    assert store.get_current(SCOPE, "1000") is record
    return {"expired_scopes_removed": removed, "old_generation": generation,
            "late_record_published": accepted}


def eviction_resurrection():
    CLOCK[0] = 1000.0
    store = session.SessionAssessmentStore(max_scopes=1)
    generation = store.generation(SCOPE)
    store.generation(OTHER)
    assert SCOPE not in store._scopes
    accepted = store.publish(SCOPE, rec(), expected_generation=generation)
    assert accepted
    return {"old_scope_was_evicted": True, "late_record_published": accepted}


def invalidation_revives_expired_assessment():
    CLOCK[0] = 1000.0
    store = session.SessionAssessmentStore(ttl_seconds=10)
    record = rec()
    store.publish(SCOPE, record)
    CLOCK[0] += 11
    before = store.get_current(SCOPE, "1000")
    store.invalidate_scope(SCOPE)
    after = store.get_current(SCOPE, "1000")
    assert before is None and after is record
    ctx = store.issue_action(SCOPE, context(record))
    accepted = store.consume_action(SCOPE, ctx.nonce, actor="userA", notification_id="1000",
                                    assessment_id=record.assessment_id, action="approval")
    assert accepted is not None
    return {"unavailable_before_invalidation": before is None,
            "expired_record_readable_after_invalidation": after is record,
            "new_action_on_expired_record_accepted": accepted is not None}


def mutable_records_and_actions():
    CLOCK[0] = 1000.0
    store = session.SessionAssessmentStore()
    record = rec()
    store.publish(SCOPE, record)
    record.recommendation = "Reject"
    record.duplicate.coverage = "unavailable"
    fetched = store.get_current(SCOPE, "1000")
    assert fetched.recommendation == "Reject" and fetched.revision == 1
    ctx = store.issue_action(SCOPE, context(record))
    args = dict(actor="userA", notification_id="1000", assessment_id=record.assessment_id,
                action="approval")
    first = store.consume_action(SCOPE, ctx.nonce, **args)
    ctx.used = False
    second = store.consume_action(SCOPE, ctx.nonce, **args)
    assert first is not None and second is not None
    return {"published_result_mutated_without_revision": True,
            "single_use_action_reused_after_returned_object_mutation": second is not None}


def capacity_not_enforced():
    CLOCK[0] = 1000.0
    store = session.SessionAssessmentStore(max_records_per_scope=2)
    for i in range(5):
        store.publish(SCOPE, rec(str(1000 + i)))
        store.item_lock(SCOPE, str(1000 + i))
    bucket = store._scopes[SCOPE]
    assert len(bucket.current) == len(bucket.by_assessment) == 5
    return {"configured_record_capacity": 2, "current_records": len(bucket.current),
            "indexed_records": len(bucket.by_assessment), "item_locks": len(store._item_locks)}


if __name__ == "__main__":
    checks = [sweep_resurrection, eviction_resurrection, invalidation_revives_expired_assessment,
              mutable_records_and_actions, capacity_not_enforced]
    print(json.dumps({check.__name__: check() for check in checks}, indent=2))
