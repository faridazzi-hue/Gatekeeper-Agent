"""Local, stdlib-only adversarial probes of the uploaded foundation, no SAP/network."""
import asyncio
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "source"))
from assessment_models import PageRun, WorklistSnapshot
from assessment_session import SessionAssessmentStore
from assessment_service import assess_one, build_record, run_page

SCOPE = ("userA", "tenant1", "conversation1")


def valid(**overrides):
    value = {
        "notification_id": "1000", "recommendation": "Approve", "confidence": "High",
        "rationale": "ok", "execution_completeness": "complete",
        "duplicate": {"coverage": "complete", "candidate_ids": [], "pool_capped": False},
        "findings": [{"field": "Planner", "result": "Pass", "evidence_available": True}],
    }
    value.update(overrides)
    return value


def show(name, **values):
    print(json.dumps({"probe": name, **values}, sort_keys=True))


def record_probes():
    probes = {
        "missing_required_fields": {"recommendation": "Approve", "confidence": "High"},
        "invalid_completeness": valid(execution_completeness="failed"),
        "wrong_notification": valid(notification_id="UNRELATED"),
        "unavailable_required_finding": valid(findings=[{"field": "Planner", "result": "Not verified", "evidence_available": False}]),
        "bad_candidate_type": valid(duplicate={"coverage": "complete", "candidate_ids": "1009"}),
        "capped_complete_pool": valid(duplicate={"coverage": "complete", "candidate_ids": [], "pool_capped": True}),
        "string_false_availability": valid(findings=[{"field": "Planner", "result": "Pass", "evidence_available": "false"}]),
        "invalid_recommendation": valid(recommendation="banana"),
    }
    for name, obj in probes.items():
        rec = build_record(obj, notification_id="1000", revision=1, run_id=None, policy_version="p1")
        show(name, notification_id=rec.notification_id,
             recommendation=rec.recommendation, confidence=rec.confidence,
             completeness=rec.execution_completeness,
             findings=[{"result": f.result, "available": f.evidence_available} for f in rec.findings],
             duplicate_clean=rec.duplicate.is_clean if rec.duplicate else None)


async def main():
    record_probes()
    s = SessionAssessmentStore()

    async def invalidating(nid):
        s.invalidate_scope(SCOPE)
        return json.dumps(valid(notification_id=nid))

    run = PageRun(snapshot_id="missing", page_index=1, member_ids=["1000"], actor="userA")
    await run_page(run, assessor=invalidating, scope=SCOPE, store=s)
    show("rejected_publish_reported_completed", counts=run.counts(), stored=s.get_current(SCOPE, "1000") is not None)

    s = SessionAssessmentStore()
    called = []

    async def collecting(nid):
        called.append(nid)
        return json.dumps(valid(notification_id=nid))

    snap = WorklistSnapshot(actor="userA", plant="1710", ordered_ids=[str(i) for i in range(20)], total=20)
    s.put_snapshot(SCOPE, snap)
    wrong_scope_run = PageRun(snapshot_id=snap.snapshot_id, page_index=1, member_ids=["NOT_ON_PAGE"], actor="somebody_else")
    await run_page(wrong_scope_run, assessor=collecting, scope=SCOPE, store=s)
    show("actor_and_page_membership_not_checked", assessed=called, counts=wrong_scope_run.counts())

    s = SessionAssessmentStore()
    calls = 0
    active = 0
    max_active = 0

    async def observed(nid):
        nonlocal calls, active, max_active
        calls += 1
        active += 1
        max_active = max(max_active, active)
        await asyncio.sleep(0.01)
        active -= 1
        return json.dumps(valid(notification_id=nid))

    runs = [PageRun(snapshot_id="none", page_index=1, member_ids=[str(offset+i) for i in range(5)], actor="userA", idempotency_key="duplicate-click") for offset in (0, 5)]
    await asyncio.gather(*(run_page(r, assessor=observed, scope=SCOPE, store=s, sap_concurrency=5) for r in runs))
    show("semaphore_is_per_run_and_idempotency_unused", calls=calls, max_active=max_active, identical_idempotency_key=True)

    s = SessionAssessmentStore()
    calls = 0
    duplicate_runs = [PageRun(snapshot_id="none", page_index=1, member_ids=["1000"], actor="userA", idempotency_key="same") for _ in range(2)]
    await asyncio.gather(*(run_page(r, assessor=observed, scope=SCOPE, store=s) for r in duplicate_runs))
    show("same_item_not_singleflight", calls=calls, revision=s.get_current(SCOPE, "1000").revision)

    s = SessionAssessmentStore()

    async def cancelled(nid):
        raise asyncio.CancelledError()

    cancelled_run = PageRun(snapshot_id="none", page_index=1, member_ids=["1000"], actor="userA")
    await run_page(cancelled_run, assessor=cancelled, scope=SCOPE, store=s)
    show("cancelled_worker_left_running", counts=cancelled_run.counts())

    s = SessionAssessmentStore()
    observed_calls = []

    async def invalidate_first(nid):
        observed_calls.append(nid)
        if nid == "1000":
            s.invalidate_scope(SCOPE)
        return json.dumps(valid(notification_id=nid))

    invalidated_run = PageRun(snapshot_id="none", page_index=1, member_ids=["1000", "1001"], actor="userA")
    await run_page(invalidated_run, assessor=invalidate_first, scope=SCOPE, store=s, sap_concurrency=1)
    show("queued_worker_survives_invalidation", assessed=observed_calls,
         first_stored=s.get_current(SCOPE,"1000") is not None,
         queued_stored=s.get_current(SCOPE,"1001") is not None,
         counts=invalidated_run.counts())


if __name__ == "__main__":
    asyncio.run(main())
