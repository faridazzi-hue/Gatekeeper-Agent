# Gatekeeper assessment foundation review

Reviewed 17 October 2026. Decision: **fix the foundation before wiring it into the live agent**.

## Scope and evidence

Reviewed the newly uploaded `gatekeeper-assessment-foundation.zip`, SHA-256 `8d6e6a8ef0570f0a55285e9cf94564aa771e8a5f41877bdbfa44a66601547ba5`. It contains the three modules, README and the supplied test file. This is an addition to the V2 application baseline, not a replacement complete application archive.

- The standard-library-only dependency claim is correct. No application or third-party imports were found.
- Ran the supplied test file unchanged: **12/12 pass**, exit code 0. The logged malformed-response warning and deliberately crashing item are expected by those tests.
- Added **14 expected-behavior regression test methods** outside the submitted source. All 14 expose failures on this version, with 18 failing assertions including subcases and zero test harness errors.
- Ran three additional isolated reproduction scripts. No SAP, model or network calls were made.
- Verified each of the five submitted files remains byte-for-byte identical to the uploaded ZIP. No production code was modified or deployed.

The existing tests establish selected happy paths and hand-picked errors. They do not establish all the advertised guarantees about validated, immutable, expired or single-flight records. The README correctly identifies tool telemetry and actual model/checkpoint isolation as later integration work; those are separated from definite foundation bugs below.

## Must fix before live integration

### F1 — Schema handling fails open and can create Approve / High without evidence

**Priority: P1.** `assessment_service.py:165-166,180-207`; `assessment_models.py:126-146`.

This response is accepted as a complete Approve / High assessment, with no findings and no duplicate search:

```json
{"recommendation":"Approve","confidence":"High"}
```

Missing completeness defaults to `complete`; every unknown completeness value is also converted to `complete`. Missing or non-list findings become an empty list, and a missing duplicate result becomes `None`, which is considered clean. Even `{}` becomes a completed record without a verdict, so a page can count a schema-invalid result as completed.

Related verified defects:

- `candidate_ids: "1002"` is silently converted to `[]` (`assessment_service.py:139-141`), erasing suspected-candidate evidence.
- `coverage="complete", pool_capped=True, candidate_ids=[]` is considered clean because `DuplicateEvidence.is_clean` ignores `pool_capped` (`assessment_models.py:90-92`).
- `evidence_available: "false"` becomes Python `True` through `bool(...)` (`assessment_service.py:116`), permitting a Pass.
- An explicitly unavailable/Not verified finding does not reconcile model-declared completeness; it can coexist with Approve. Which evidence is required must be determined by the trusted check/source contract, not by guessing from a model field label.

**Correction:** validate the complete schema and exact types before building a supported result. Missing/invalid required fields produce incomplete/no recommendation/no confidence. Never convert a missing duplicate result into a clean search, erase a malformed candidate list, or interpret string booleans by truthiness. Approval must require affirmative, consistent duplicate coverage and the expected required checks/sources. A valid manual-referral result is distinct from a malformed or incomplete execution; do not manufacture one as a generic repair.

The existing explicit `execution_completeness="incomplete"` branch already clears recommendation and confidence correctly. Preserve it; fix the paths that wrongly normalize malformed input to complete.

### F2 — Wrong-notification output is silently relabeled

**Priority: P1.** `assessment_service.py:150-156,210-211`.

The payload's `notification_id` is never checked. A response for `9999` is stored as requested notification `1000`, retaining the other notification's summary/evidence. Parallel isolation and a typed result cannot protect against this if the final identity is silently overwritten.

**Correction:** require the returned identity to match the server's full canonical requested ID. On mismatch or missing identity, produce an incomplete result and disable actions. Do not truncate IDs or let the model select another target.

### F3 — The canonical snapshot is mutable; the nonce-used flag is exposed

**Priority: P1.** `assessment_models.py:97-124,159-176`; `assessment_session.py:161-171,205-206,225-228,261-263`.

`AssessmentRecord` is documented immutable but is a normal mutable dataclass. Its findings, duplicate evidence and summary dictionary are mutable too. Publication stores the caller's object; getters return that same object. A detail consumer can change Rework to Approve, Fail to Pass, and summary text without changing the assessment ID/revision or re-running constructor guardrails.

The action context has the same reference-exposure issue. After a successful consume, resetting the returned object's `used=False` lets the same nonce consume again. This demonstrates a broken internal single-use guarantee, not a confirmed external exploit or SAP write.

**Correction:** use deeply immutable snapshots or defensive copies at publication and read boundaries. `frozen=True` alone does not freeze nested lists/dictionaries. Keep action-use state private in the store; return immutable projections rather than exposing the authorization object's mutable state.

### F4 — Expiry and run-generation fencing can be bypassed

**Priority: P1.** `assessment_session.py:110-130,144-157,177-208,298-305`; `assessment_service.py:259-280,299-321`.

Four related behaviors were reproduced:

1. `sweep()` or capacity eviction removes a bucket and its generation. Later publication recreates it at generation 0, accepting an old worker that captured generation 0. The tested expiry-without-deletion path passes; the actual deletion/recreation path does not.
2. `invalidate_scope()` calls `touch()` on an expired bucket without clearing its current records. An unavailable expired assessment becomes readable again, and a new action for it can be issued and consumed.
3. `assess_one()` ignores `publish(False)` and returns the rejected record. The page runner reports it completed although no canonical record exists.
4. Queued items capture the generation only after entering the semaphore/item lock. After a page is invalidated, its old queued work can adopt the new generation and publish into the refreshed scope.

Concrete two-item reproduction with concurrency 1: the first item invalidates the scope; its publication is rejected but counted completed; the second old-page item publishes Approve / High under the new generation. Both are reported completed.

**Correction:** use a unique scope incarnation/run token that cannot reset after eviction. Capture it when accepting the page, carry it through queued workers, and verify it before work, publication and actionable output. Publication by an old worker must not create/revive its own scope. Expiry/invalidation should clear or explicitly retire stale results/actions. Propagate rejected publication as invalidated/cancelled rather than completed. Prevent late progress events from resurrecting processed or expired UI actions.

This remains an in-memory solution; no database is required.

### F5 — Item locks serialize repeated scoring instead of reusing it

**Priority: P1 for the consistency requirement.** `assessment_service.py:259-264,299`; `assessment_session.py:274-281`.

Two simultaneous submissions with the same idempotency key still call the assessor twice for the same notification and create revision 2. `find_run_by_idempotency` exists but `run_page` does not use it. The per-item lock prevents simultaneous publication; it does not join in-flight work or reuse a current result.

Consequences include duplicate model cost, a changed recommendation without an explicit reassessment request, and unexpectedly invalidated action contexts.

**Correction:** atomically admit/join a run using its authorized snapshot/page/membership/policy and idempotency key. Reuse or join a valid current/in-flight assessment by default. Make explicit reassessment a distinct input. Do not implement lookup-then-start without coordination, which would leave a race.

### F6 — Cancellation can leave the page permanently running

**Priority: P2; resolve before enabling live page runs.** `assessment_service.py:302-321`.

An assessor raising `asyncio.CancelledError` leaves the item as running. `gather(return_exceptions=True)` discards that outcome, and `run_page` returns normally with `running=1` and no terminal update. No deadline is supplied for a hung assessor either.

**Correction:** define cancellation/timeout behavior, settle item/run state in cleanup, preserve parent cancellation semantics, and emit the terminal state. Do not silently treat cancellation as successful run completion. Explicit reassessment failure must not leave an older outdated assessment silently actionable.

### F7 — Capacity settings do not bound memory as advertised

**Priority: P2; important for an in-memory BTP app.** `assessment_session.py:122-137,210-221,298-305`.

With `max_records_per_scope=2`, publishing five distinct notifications retains all five current records and all five indexed records. Only superseded records are eligible for eviction, so current records bypass the cap. Capacity eviction also drops scopes without dropping their item-lock entries; a later sweep cannot discover those already-removed scopes.

**Correction:** define and enforce an actual capacity/eviction or admission-rejection policy, including current records and invalidation of their actions. Bound retained runs, snapshots, actions and locks as well. Do not remove an active lock in a way that lets another task bypass it; coordinate cleanup with outstanding work.

## Required integration contracts — separate from the defects above

The package intentionally does not integrate the live agent. That decoupling is useful. These obligations must be implemented and tested at an explicit server boundary before live wiring is considered complete:

1. **Real evidence:** the injected assessor currently returns text only. Reconcile the result with captured real tool outcomes and an expected required-check/source manifest. The model cannot certify its own successful retrieval, field values or complete coverage. A trusted execution/evidence object can remain standard-library-only.
2. **Actual full review:** use the full single-review capability, with a dedicated structured-output contract. Appending JSON instructions to prompts that still demand Markdown/HIL tables leaves conflicting output rules.
3. **Model/checkpoint isolation:** the supplied concurrency test counts unique notification IDs/coroutines. It does not test LangGraph thread IDs, tool context or evidence attribution. Use isolated item contexts and clean up their temporary checkpoint evidence.
4. **Page admission:** validate the verified actor/scope, live authorized snapshot, page index and exact captured 20-or-fewer unique members. Currently `run_page` accepts a different actor and `NOT_ON_PAGE` ID even when a real snapshot exists. Either construct the run only through a trusted validating factory or enforce admission in the service; do not wire client-supplied `PageRun` fields straight through.
5. **Aggregate limits:** `sap_concurrency` limits complete assessor calls per run, not all SAP operations or the application. Two runs configured at 5 reached 10 active assessors. Add shared resource limits/backpressure appropriate to the single-process deployment and separate model/SAP resources where needed.
6. **Policy provenance:** pin one policy/model/prompt context per run and every result. `PageRun.policy_version` can currently differ from the separate service argument; model/prompt versions are not propagated by `assess_one`.
7. **HIL eligibility:** exact nonce matching is not the whole authorization decision. Enforce complete/current assessment, action/recommendation compatibility, override reason, additional Low-confidence acknowledgment, real SAP pending-state eligibility and relevant freshness. Derive actor/tenant/backend/conversation from trusted context. Do not reissue actions from an old result merely because it remains readable after list invalidation.
8. **Progress contract:** the callback is currently synchronous. A2A update methods are asynchronous; use an explicitly awaited async callback or an intentional tested bridge rather than passing an unawaited coroutine.
9. **Business state remains SAP:** Show Remaining refreshes actual pending eligibility/count/list. Assessment alone never removes a notification. Verified SAP processing removes it when its status leaves the pending scope; a late assessment result must not re-enable it. Uncertain mutations require backend outcome reconciliation, not blind replay.
10. **No durable agent data:** retain the temporary-session design. Align the one-worker/instance ownership, TTL/capacity cleanup, safe session-loss behavior and actual checkpointer configuration already described in the reviewed implementation plan.

None of this requires adding a durable BTP database, another model, or a multi-agent platform.

## Correction order

1. Fix strict result validation, duplicate coverage and identity checks (F1/F2).
2. Protect canonical snapshots and internal nonce-use state (F3).
3. Repair scope-incarnation/run fencing and publish-result handling (F4).
4. Add atomic run/result reuse with explicit reassessment (F5).
5. Close cancellation/capacity cleanup gaps (F6/F7).
6. Rerun the supplied tests plus the review regressions. Add integration tests for actual tool evidence, checkpoint separation, exact page scope and HIL eligibility.
7. Wire one real notification first, then a 20-item page, then display-only details/HIL. Keep QA verification separate from claims about current live behavior.

## Reproduction and test artifacts

Files in `review-checks/`:

- `dependency-check.json`: import verification.
- `supplied-tests.stdout.txt` and `.stderr.txt`: original test output, 12/12 passed.
- `test_review_regressions.py`: 14 expected-behavior methods; currently fail on the submitted implementation. Subtests account for 18 assertion failures.
- `additional-regressions.summary.json` and `.output.txt`: machine-readable summary and full traces.
- `models_repro.py`, `session_repro.py`, `service_repro.py` and their captured outputs: isolated observations of current behavior. Successful reproduction scripts confirm defects still exist; they are not proof of fixes.

Run review regressions with Python 3.11+:

```sh
GATEKEEPER_FOUNDATION_SOURCE=/path/to/unzipped/foundation python3 -B review-checks/test_review_regressions.py
```

The original reproduction scripts expect the submitted modules in a sibling `source/` directory; adjust that path if using another layout. Review tests may need deliberate adaptation if the correction changes the public API or capacity-error contract. Do not merely weaken the expected invariants to make the current code pass.

## Handoff to the coding assistant

Pause live integration. Keep the decoupled, standard-library-only design and fix F1-F7 first. Return the revised modules, updated tests and actual output. Integrate only after strict fail-closed schema/identity, deep snapshot protection, expiry/run fencing, idempotent reuse and terminal-state cleanup are demonstrated. Treat actual SAP telemetry, checkpoint isolation, page admission and HIL business eligibility as explicit integration deliverables. SAP remains the authoritative business state; no durable agent-side storage is requested.
