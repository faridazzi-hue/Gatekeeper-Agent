"""Show the user-visible consequence of a same-key completed retry; fake assessor only."""
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source"))
from assessment_models import PageRun
from assessment_service import run_page
from assessment_session import SessionAssessmentStore


async def main():
    scope = ("reviewer", "demo", "same-operation")
    store = SessionAssessmentStore()
    calls = 0

    async def assessor(nid):
        nonlocal calls
        calls += 1
        return json.dumps({
            "notification_id": nid, "execution_completeness": "complete",
            "recommendation": "Approve" if calls == 1 else "Rework",
            "confidence": "High" if calls == 1 else "Medium",
            "rationale": "First result" if calls == 1 else "Second result",
            "findings": [{"field": "Planner", "result": "Pass" if calls == 1 else "Fail",
                          "evidence_available": True}],
            "duplicate": {"coverage": "complete", "candidate_ids": [], "pool_capped": False},
        })

    rows = []
    for _ in range(2):
        run = PageRun("snapshot", 1, ["1000"], "reviewer", idempotency_key="same-request")
        await run_page(run, assessor=assessor, scope=scope, store=store)
        rec = store.get_current(scope, "1000")
        rows.append({"run_id": run.run_id, "assessment_id": rec.assessment_id,
                     "revision": rec.revision, "recommendation": rec.recommendation,
                     "confidence": rec.confidence})
    print(json.dumps({"assessor_calls": calls, "same_key_results": rows}, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
