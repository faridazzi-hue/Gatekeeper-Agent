"""Expected-behavior session follow-ups; no network, model or source changes."""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source"))
from assessment_models import AssessmentRecord, WorklistSnapshot
import assessment_session as session

A = ("alice", "tenant", "conversation-a")
B = ("bob", "tenant", "conversation-b")


def record():
    return AssessmentRecord(notification_id="1000", recommendation="Rework",
                            confidence="High", rationale="fixture")


class SessionFollowups(unittest.TestCase):
    def test_rejected_worker_cannot_evict_another_session(self):
        store = session.SessionAssessmentStore(max_scopes=1)
        old_generation = store.generation(A)
        live = record()
        store.publish(B, live)
        self.assertFalse(store.publish(A, record(), expected_generation=old_generation))
        self.assertIsNotNone(store.get_current(B, "1000"))
        self.assertNotIn(A, store._scopes)

    def test_rejected_worker_cannot_extend_session_ttl(self):
        clock = [1000.0]
        with patch.object(session, "_now", side_effect=lambda: clock[0]):
            store = session.SessionAssessmentStore(ttl_seconds=10)
            old_generation = store.generation(A)
            store.invalidate_scope(A)
            store.publish(A, record(), expected_generation=store.generation(A))
            clock[0] += 9
            self.assertFalse(store.publish(A, record(), expected_generation=old_generation))
            clock[0] += 2
            self.assertIsNone(store.get_current(A, "1000"))

    def test_snapshot_getter_cannot_mutate_canonical_membership(self):
        store = session.SessionAssessmentStore()
        original = WorklistSnapshot(actor="alice", plant="1710", ordered_ids=["1000"], total=1)
        store.put_snapshot(A, original)
        returned = store.get_snapshot(A, original.snapshot_id)
        try:
            returned.ordered_ids.append("NOT-IN-ORIGINAL-PAGE")
        except (AttributeError, TypeError):
            pass
        self.assertEqual(store.get_snapshot(A, original.snapshot_id).ordered_ids, ["1000"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
