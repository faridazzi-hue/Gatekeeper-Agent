"""Focused V3 schema safety checks, independent of SAP/model integration."""
import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'source'))
from assessment_service import build_record


def payload():
    return {'notification_id': '1000', 'execution_completeness': 'complete',
            'recommendation': 'Approve', 'confidence': 'High', 'rationale': 'All checks passed.',
            'findings': [{'field': 'Equipment', 'retrieved_value': 'EQ-1',
                          'result': 'Pass', 'evidence_available': True}],
            'duplicate': {'coverage': 'complete', 'candidate_ids': [], 'pool_capped': False}}


def record(p):
    return build_record(p, notification_id='1000', revision=1, run_id=None, policy_version='fixture')


class V3SchemaSafety(unittest.TestCase):
    def assertIncomplete(self, rec):
        self.assertEqual(rec.execution_completeness, 'incomplete')
        self.assertIsNone(rec.recommendation)
        self.assertIsNone(rec.confidence)

    def test_unavailable_duplicate_invalidates_each_verdict(self):
        for verdict in ('Approve', 'Rework', 'Reject', 'Review Needed'):
            with self.subTest(verdict=verdict):
                p = payload(); p['recommendation'] = verdict
                p['duplicate']['coverage'] = 'unavailable'
                self.assertIncomplete(record(p))

    def test_required_boolean_fields_are_not_truthiness_coerced(self):
        for value in ('true', 'false', 0, 1, None, [], {}):
            for field in ('evidence_available', 'pool_capped'):
                with self.subTest(field=field, value=value):
                    p = payload()
                    target = p['findings'][0] if field == 'evidence_available' else p['duplicate']
                    target[field] = value
                    self.assertIncomplete(record(p))

    def test_all_complete_verdicts_reject_unavailable_findings(self):
        for verdict in ('Approve', 'Rework', 'Reject', 'Review Needed'):
            for finding in ({'result': 'Pass', 'evidence_available': False},
                            {'result': 'Not verified', 'evidence_available': True}):
                with self.subTest(verdict=verdict, finding=finding):
                    p = payload(); p['recommendation'] = verdict; p['findings'][0].update(finding)
                    self.assertIncomplete(record(p))

    def test_factual_override_retains_valid_high_referral_confidence(self):
        for mutation in ('finding_fail', 'partial_duplicate', 'capped_duplicate', 'candidate'):
            with self.subTest(mutation=mutation):
                p = payload()
                if mutation == 'finding_fail': p['findings'][0]['result'] = 'Fail'
                if mutation == 'partial_duplicate': p['duplicate']['coverage'] = 'partial'
                if mutation == 'capped_duplicate': p['duplicate']['pool_capped'] = True
                if mutation == 'candidate': p['duplicate']['candidate_ids'] = ['1001']
                rec = record(p)
                self.assertEqual(rec.execution_completeness, 'complete')
                self.assertEqual(rec.recommendation, 'Review Needed')
                self.assertEqual(rec.confidence, 'High')
                self.assertNotEqual(rec.rationale, p['rationale'])
                self.assertIn('manual decision', rec.rationale)


if __name__ == '__main__':
    unittest.main(verbosity=2)
