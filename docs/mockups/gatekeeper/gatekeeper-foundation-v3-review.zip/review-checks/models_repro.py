"""Additional v2 fail-closed regressions. No SAP/model calls or source edits."""
import copy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "source"))
from assessment_service import build_record


def payload():
    return {
        "notification_id": "1000", "execution_completeness": "complete",
        "recommendation": "Approve", "confidence": "High",
        "rationale": "All checks passed; approve this notification.",
        "findings": [{"field": "Equipment", "retrieved_value": "EQ-1",
                      "result": "Pass", "evidence_available": True}],
        "duplicate": {"coverage": "complete", "candidate_ids": [], "pool_capped": False},
    }


def build(obj):
    return build_record(obj, notification_id="1000", revision=1,
                        run_id=None, policy_version="fixture")


class AdditionalSchemaRegressions(unittest.TestCase):
    def test_missing_duplicate_evidence_fields_cannot_support_approve(self):
        for missing in ("candidate_ids", "pool_capped"):
            with self.subTest(missing=missing):
                obj = payload()
                del obj["duplicate"][missing]
                rec = build(obj)
                self.assertEqual(rec.execution_completeness, "incomplete")
                self.assertIsNone(rec.recommendation)
                self.assertIsNone(rec.confidence)

    def test_missing_finding_availability_cannot_be_affirmative_evidence(self):
        obj = payload()
        del obj["findings"][0]["evidence_available"]
        rec = build(obj)
        self.assertEqual(rec.execution_completeness, "incomplete")
        self.assertIsNone(rec.recommendation)

    def test_unhashable_enum_shapes_return_incomplete_instead_of_crashing(self):
        for field in ("recommendation", "confidence", "finding.result"):
            for value in ([], {}):
                with self.subTest(field=field, value=value):
                    obj = payload()
                    if field == "finding.result":
                        obj["findings"][0]["result"] = copy.deepcopy(value)
                    else:
                        obj[field] = copy.deepcopy(value)
                    rec = build(obj)
                    self.assertEqual(rec.execution_completeness, "incomplete")
                    self.assertIsNone(rec.recommendation)
                    self.assertIsNone(rec.confidence)

    def test_unavailable_duplicate_source_is_incomplete_not_high_confidence_verdict(self):
        obj = payload()
        obj["duplicate"]["coverage"] = "unavailable"
        rec = build(obj)
        self.assertEqual(rec.execution_completeness, "incomplete")
        self.assertIsNone(rec.recommendation)
        self.assertIsNone(rec.confidence)

    def test_downgraded_verdict_does_not_keep_original_approval_explanation(self):
        obj = payload()
        obj["findings"][0]["result"] = "Fail"
        rec = build(obj)
        self.assertEqual(rec.recommendation, "Review Needed")
        self.assertNotEqual(rec.rationale, obj["rationale"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
