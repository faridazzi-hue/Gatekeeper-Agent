"""Additional V3 runner contract checks; no application wiring or source changes."""
import asyncio
import json
import os
import pathlib
import sys
import unittest

sys.path.insert(0, os.environ.get("GATEKEEPER_REVIEW_SOURCE",
                                str(pathlib.Path(__file__).resolve().parents[1] / "source")))
from assessment_models import PageRun
from assessment_service import run_page
from assessment_session import SessionAssessmentStore

SCOPE = ("reviewer", "demo", "runner-lifecycle")


def payload(nid):
    return json.dumps({
        "notification_id": nid, "execution_completeness": "complete",
        "recommendation": "Approve", "confidence": "High", "rationale": "All pass.",
        "findings": [{"field": "equipment", "result": "Pass", "evidence_available": True}],
        "duplicate": {"coverage": "complete", "candidate_ids": [], "pool_capped": False},
    })


def page(key):
    return PageRun("snapshot", 1, ["1000"], "reviewer", idempotency_key=key)


class RunnerLifecycleV3(unittest.IsolatedAsyncioTestCase):
    async def test_retry_completed_key_distinct_run_id_reuses_result(self):
        store = SessionAssessmentStore()
        calls = 0

        async def assessor(nid):
            nonlocal calls
            calls += 1
            return payload(nid)

        first = await run_page(page("network-retry"), assessor=assessor, scope=SCOPE, store=store)
        first_record = store.get_current(SCOPE, "1000")
        retry = await run_page(page("network-retry"), assessor=assessor, scope=SCOPE, store=store)
        second_record = store.get_current(SCOPE, "1000")
        self.assertEqual(calls, 1, "same operation key scored twice after completion")
        self.assertEqual(first.run_id, retry.run_id)
        self.assertEqual(first_record.assessment_id, second_record.assessment_id)

    async def test_retry_completed_key_same_run_object_reuses_result(self):
        store = SessionAssessmentStore()
        calls = 0

        async def assessor(nid):
            nonlocal calls
            calls += 1
            return payload(nid)

        run = page("same-object-retry")
        await run_page(run, assessor=assessor, scope=SCOPE, store=store)
        first_record = store.get_current(SCOPE, "1000")
        await run_page(run, assessor=assessor, scope=SCOPE, store=store)
        second_record = store.get_current(SCOPE, "1000")
        self.assertEqual(calls, 1, "same operation object/key scored twice after completion")
        self.assertEqual(first_record.assessment_id, second_record.assessment_id)


if __name__ == "__main__":
    unittest.main(verbosity=2)
