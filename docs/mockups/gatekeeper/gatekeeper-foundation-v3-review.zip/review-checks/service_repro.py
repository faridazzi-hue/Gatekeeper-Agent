"""Service edge cases in foundation v2; source is never modified.

Run: python -B /workspace/gatekeeper-review/foundation-v2/review-checks/service_repro.py
These assertions describe the published F4/F5/F6 contracts. Four tests currently fail.
"""
import asyncio
import json
import pathlib
import sys
import unittest

SOURCE = pathlib.Path(__file__).resolve().parents[1] / "source"
sys.path.insert(0, str(SOURCE))
from assessment_models import PageRun
from assessment_service import assess_one, run_page
from assessment_session import SessionAssessmentStore

SCOPE = ("reviewer", "demo", "session")


def payload(nid):
    return json.dumps({
        "notification_id": nid,
        "execution_completeness": "complete",
        "recommendation": "Approve", "confidence": "High", "rationale": "All checks pass.",
        "findings": [{"field": "equipment", "retrieved_value": "EQ1", "result": "Pass",
                      "evidence_available": True}],
        "duplicate": {"coverage": "complete", "candidate_ids": [], "pool_capped": False},
    })


def page(ids=None, **kwargs):
    return PageRun("snapshot", 1, ids or ["1000"], "reviewer", **kwargs)


class ServiceEdgeCases(unittest.IsolatedAsyncioTestCase):
    async def test_cancelled_page_settles_semaphore_waiters(self):
        store = SessionAssessmentStore()
        entered = asyncio.Event()

        async def assessor(nid):
            entered.set()
            await asyncio.Event().wait()
            return payload(nid)

        run = page(["1000", "1001", "1002"], idempotency_key="cancel")
        task = asyncio.create_task(run_page(run, assessor=assessor, scope=SCOPE,
                                            store=store, sap_concurrency=1))
        await entered.wait()
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await task
        self.assertFalse(any(s in ("queued", "running") for s in run.item_states.values()),
                         f"page is done but nonterminal states remain: {run.item_states}")

    async def test_same_run_id_submission_joins(self):
        store = SessionAssessmentStore()
        entered = asyncio.Event()
        release = asyncio.Event()
        calls = 0

        async def assessor(nid):
            nonlocal calls
            calls += 1
            entered.set()
            await release.wait()
            return payload(nid)

        run = page(idempotency_key="same-run")
        first = asyncio.create_task(run_page(run, assessor=assessor, scope=SCOPE, store=store))
        await entered.wait()
        second = asyncio.create_task(run_page(run, assessor=assessor, scope=SCOPE, store=store))
        await asyncio.sleep(0)
        release.set()
        await asyncio.gather(first, second)
        self.assertEqual(calls, 1, "same run/idempotency key was executed twice")
        self.assertEqual(store.get_current(SCOPE, "1000").revision, 1)

    async def test_standalone_lock_waiter_does_not_adopt_new_generation(self):
        store = SessionAssessmentStore()
        store.generation(SCOPE)
        lock = store.item_lock(SCOPE, "1000")
        await lock.acquire()

        async def assessor(nid):
            return payload(nid)

        task = asyncio.create_task(assess_one("1000", assessor=assessor, scope=SCOPE,
                                             store=store))
        await asyncio.sleep(0)  # assessment has entered and is waiting on the item lock
        store.invalidate_scope(SCOPE)
        lock.release()
        await task
        self.assertIsNone(store.get_current(SCOPE, "1000"),
                          "pre-invalidation call adopted the new generation after waiting")

    async def test_standalone_rejected_publish_not_returned_as_complete(self):
        store = SessionAssessmentStore()
        old_generation = store.generation(SCOPE)
        store.invalidate_scope(SCOPE)

        async def assessor(nid):
            return payload(nid)

        try:
            result = await assess_one("1000", assessor=assessor, scope=SCOPE, store=store,
                                      expected_generation=old_generation)
        except Exception:
            return  # an explicit stale-publication failure is acceptable
        self.assertIsNone(store.get_current(SCOPE, "1000"))
        self.assertNotEqual(result.execution_completeness, "complete",
                            "caller receives a complete, actionable-looking unpublished result")

    async def test_distinct_run_ids_same_key_are_joined(self):
        """Positive control: the supplied concurrent-idempotency scenario works."""
        store = SessionAssessmentStore()
        entered = asyncio.Event()
        release = asyncio.Event()
        calls = 0

        async def assessor(nid):
            nonlocal calls
            calls += 1
            entered.set()
            await release.wait()
            return payload(nid)

        run1 = page(idempotency_key="same-key")
        run2 = page(idempotency_key="same-key")
        task1 = asyncio.create_task(run_page(run1, assessor=assessor, scope=SCOPE, store=store))
        await entered.wait()
        task2 = asyncio.create_task(run_page(run2, assessor=assessor, scope=SCOPE, store=store))
        await asyncio.sleep(0)
        release.set()
        one, two = await asyncio.gather(task1, task2)
        self.assertEqual(calls, 1)
        self.assertIs(one, two)


if __name__ == "__main__":
    unittest.main(verbosity=2)
