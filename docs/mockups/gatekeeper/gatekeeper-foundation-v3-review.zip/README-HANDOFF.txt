Gatekeeper foundation V3 review handoff
======================================

Start with FOUNDATION-V3-REVIEW.md. Previous R1-R6 fixes pass; one completed-key
retry regression needs correction before enabling run_page.

This package contains review documents, source identity hashes, expected-behavior
tests and their outputs. It deliberately does NOT contain the submitted application
or foundation source. No production source was modified or deployed.

To reproduce, create a source/ directory next to review-checks/ and copy the three
assessment_*.py modules from the uploaded V3 package into it. For the supplied
foundation suite, also copy test_assessment_foundation.py into source/.

From this package's directory:
  python3 -B source/test_assessment_foundation.py
  python3 -B review-checks/models_repro.py
  python3 -B review-checks/service_repro.py
  python3 -B review-checks/test_session_followups.py
  python3 -B review-checks/test_review_regressions.py
  python3 -B review-checks/schema_v3_extra.py
  python3 -B review-checks/session_agent_regressions.py
  python3 -B review-checks/test_runner_lifecycle_v3.py
  python3 -B review-checks/retry_observation.py

All baseline checks pass against V3. test_runner_lifecycle_v3.py currently exits 1:
its two failures describe ONE bug, completed retries execute the assessor twice.
The observation script prints behavior rather than making release assertions.

Keep the assertions when fixing the source. Equivalent defensive-copy return
objects are acceptable; operation identity and saved assessment must remain stable.
Explicit reassessment uses a distinct operation key; no durable storage is required.
