"""Read-only V2 routing regression reproduction, with no app imports or SAP calls.

Extract only regex assignments, target dictionary, and pure _classify_mode from
the supplied source AST. This deliberately avoids executing imports, module
startup, model calls, or uploaded plan instructions.
"""
import ast
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "v2/assets/pm-gatekeeper-agent-rpt-toggle/app/agent_executor.py"
OUTPUT = Path(__file__).with_name("routing-results.json")
tree = ast.parse(SOURCE.read_text(encoding="utf-8"))
keep = {"_RE_BULK", "_RE_REVIEW", "_RE_ACCEPT", "_RE_LIST", "_ACTIVE_TARGET"}
nodes = []
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name == "_classify_mode":
        nodes.append(node)
    elif isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id in keep for target in node.targets
    ):
        nodes.append(node)
    elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id in keep:
        nodes.append(node)
namespace = {"re": re}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), "exec"), namespace)
classify = namespace["_classify_mode"]
results = []


def check(name, actual, expected, implication):
    assert actual == expected, (name, actual, expected)
    results.append({"name": name, "actual": actual, "verified": True, "implication": implication})


context = "isolated-routing-review"
check("show_details_routes_to_list", classify("Show details for notification 10002256", None, context),
      ("list", None, None), "New link text requires a distinct display route.")
check("review_sets_last_target", classify("Review notification 10002256", None, context),
      ("review_single", "10002256", None), "Sets active target for the following isolated checks.")
check("negated_accept_authorizes_action", classify("Do not accept approval", None, context),
      ("confirmed_action", "10002256", "approval"), "Substring matching classifies a refusal as confirmation.")
check("question_about_accept_authorizes_action", classify("Can you explain what accept approval means?", None, context),
      ("confirmed_action", "10002256", "approval"), "An explanatory question is classified as confirmation.")
check("existing_regex_truncates_long_id", classify("Review notification 10002256123", None, context),
      ("review_single", "1000225612", None), "No terminal digit boundary: existing route silently truncates an ID.")
check("explanation_has_general_mode", classify("Why did you recommend rework?", None, context),
      ("general", None, None), "A canonical assessment read route is needed for contextual explanations.")

proposed = re.compile(r"(?:review|show details for)\s+(?:notification\s+)?(\d{8})", re.IGNORECASE)
def proposed_target(text):
    match = proposed.search(text)
    return match.group(1) if match else None

check("proposed_regex_truncates_nine_digit_id", proposed_target("Review notification 100022561"),
      "10002256", "Proposed eight-digit regex retains a partial-ID match.")
check("proposed_regex_rejects_previously_supported_six_digit_id", proposed_target("Review notification 100022"),
      None, "Proposed pattern narrows existing six-to-ten-digit compatibility.")
check("proposed_regex_accepts_new_details_phrase", proposed_target("Show details for notification 10002256"),
      "10002256", "New link phrase matches, but regex alone does not create display-only semantics.")

report = {
    "source": str(SOURCE),
    "method": "AST-extracted pure routing definitions; no app imports, model calls or SAP calls",
    "scope_clarification": "Batch assessment covers only the current displayed page (up to 20 IDs), captured at run start; later paging cannot expand it.",
    "verified_check_count": len(results),
    "all_reproductions_verified": all(item["verified"] for item in results),
    "checks": results,
}
OUTPUT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2))
