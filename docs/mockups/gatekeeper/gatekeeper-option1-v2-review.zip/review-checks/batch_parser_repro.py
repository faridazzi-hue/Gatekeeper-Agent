"""Read-only isolated regression reproduction for the uploaded V2 batch parser.

Loads only the parser AST to avoid importing application/network dependencies.
The fixture includes a successful A response, a non-JSON HTTP 500 B response,
and a successful C response. A safe request/result mapping must retain B's slot.
"""
import ast
import json
import logging
from pathlib import Path
import re
import sys

SOURCE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/workspace/gatekeeper-review/v2/assets/pm-gatekeeper-agent-rpt-toggle/app/s4hana_client.py')
tree = ast.parse(SOURCE.read_text())
parser = next(node for node in tree.body
              if isinstance(node, ast.FunctionDef) and node.name == '_parse_batch_response')
namespace = {'re': re, 'json': json, 'logger': logging.getLogger('review'), 'Any': object}
exec(compile(ast.Module(body=[parser], type_ignores=[]), str(SOURCE), 'exec'), namespace)


def part(status, body):
    return ('--abc\r\nContent-Type: application/http\r\n\r\nHTTP/1.1 '
            + status + '\r\nContent-Type: application/json\r\n\r\n' + body + '\r\n')


body = (part('200 OK', '{"d":{"key":"A"}}')
        + part('500 Internal Server Error', 'backend unavailable')
        + part('200 OK', '{"d":{"key":"C"}}')
        + '--abc--\r\n')
result = namespace['_parse_batch_response'](body, 'multipart/mixed; boundary=abc')
report = {
    'source': str(SOURCE),
    'fixture': ['A: 200 JSON', 'B: 500 non-JSON', 'C: 200 JSON'],
    'input_parts': 3,
    'parsed_parts': len(result),
    'parsed_keys': [item['d']['key'] for item in result],
    'retains_one_slot_per_request': len(result) == 3,
    'finding': 'Failed B disappears; index-based zip would map C to B. Existing bulk duplicate tool does not call batch_get, so this is a blocker for proposed batching, not its current fan-out path.',
}
print(json.dumps(report, indent=2))
assert report['parsed_keys'] == ['A', 'C'], 'V2 behavior changed; re-evaluate the finding.'
